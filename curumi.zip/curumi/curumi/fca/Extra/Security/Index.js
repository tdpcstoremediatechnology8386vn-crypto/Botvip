/* eslint-disable linebreak-style */
module.exports = {
    Default: require('./Base'),
    GCM: require('./AES_256_GCM')
};