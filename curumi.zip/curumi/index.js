const { spawn } = require("child_process");
const logger = require("./bat/log");

function startBot(message) {
    // Add the custom ASCII art without gradient
    const customAsciiArt = `██████╗ ██╗   ██╗██████╗ ██╗   ██╗███╗   ███╗██╗
██╔════╝ ██║   ██║██╔══██╗██║   ██║████╗ ████║██║
██║  ███╗██║   ██║██████╔╝██║   ██║██╔████╔██║██║
██║   ██║██║   ██║██╔═══╝ ██║   ██║██║╚██╔╝██║╚═╝
╚██████╔╝╚██████╔╝██║     ╚██████╔╝██║ ╚═╝ ██║██╗
 ╚═════╝  ╚═════╝ ╚═╝      ╚═════╝ ╚═╝     ╚═╝╚═╝`;
    (message) ? logger(`${customAsciiArt}\n${message}`, "Bắt Đầu") : "";

    const child = spawn("node", ["--trace-warnings", "--async-stack-traces", "curumi.js"], {
        cwd: __dirname,
        stdio: "inherit",
        shell: true
    });

    child.on("close", async (codeExit) => {
        var x = 'codeExit'.replace('codeExit', codeExit);
        if (codeExit == 1) return startBot("Khởi Động Lại...");
        else if (x.indexOf(2) == 0) {
            await new Promise(resolve => setTimeout(resolve, parseInt(x.replace(2, '')) * 1000));
            startBot("Mở ...");
        }
        else return;
    });

    child.on("error", function (error) {
        logger("An error occurred: " + JSON.stringify(error), "Loading");
    });
}

startBot();
