const chalk = require('chalk');

// Chúng ta sẽ import gradient-string một cách động khi cần thiết
// const gradient = require('gradient-string'); // Bỏ dòng này

const logWithColor = async (data, option) => { // Đổi thành async
  try {
    const gradient = await import('gradient-string').then(mod => mod.default || mod); // Import động

    let coloredData = '';

    switch (option) {
      case 'warn':
        coloredData = gradient('#3aed34', '#c2ed34').multiline('WARN → ' + data);
        console.log(chalk.bold(coloredData));
        break;
      case 'error':
        coloredData = chalk.bold.hex('#FF0000')('WARN → ') + chalk.bold.red(data);
        console.log(coloredData);
        break;
      default:
        coloredData = gradient('#ed3491', '#cb34ed', '#347bed', '#deed34').multiline(`${option} : ` + data);
        console.log(chalk.bold(coloredData));
        break;
    }
  } catch (error) {
    console.error('Error loading gradient-string or applying gradient:', error);
    // Fallback to basic chalk if gradient fails
    if (option === 'error') {
       console.log(chalk.bold.hex('#FF0000')('『 WARN 』 → ') + chalk.bold.red(data));
    } else {
       console.log(chalk.bold(`${option} : ` + data));
    }
  }
};

const loaderWithColor = async (data, option) => { // Đổi thành async
   try {
     const gradient = await import('gradient-string').then(mod => mod.default || mod); // Import động

     let coloredData = '';

     switch (option) {
       case 'warn':
         coloredData = gradient('#00FFFF' , '#00FF33' , '#FFCCFF' , '#ed3491', '#0000FF' , '#cb34ed' ,'#00FF00' , '#347bed' , '#00EE00').multiline('Curumi →' + data);
         console.log(chalk.bold(coloredData));
         break;
       case 'error':
         coloredData = chalk.bold.hex('#FF0000')('Curumi →') + chalk.bold.red(data);
         console.log(coloredData);
         break;
       default:
         coloredData = gradient('#ed3491', '#cb34ed', '#347bed','#3366FF' , '#FF3366','#0000FF' , '#00DD00').multiline('Currumi → ' + data);
         console.log(chalk.bold(coloredData));
         break;
     }
   } catch (error) {
     console.error('Error loading gradient-string or applying gradient in loader:', error);
      // Fallback to basic chalk if gradient fails
     if (option === 'error') {
       coloredData = chalk.bold.hex('#FF0000')('Curumi →') + chalk.bold.red(data);
       console.log(coloredData);
     } else {
       coloredData = chalk.bold('Currumi → ' + data);
       console.log(coloredData);
     }
   }
};


module.exports = logWithColor;
module.exports.loader = loaderWithColor;

