const moment = require("moment-timezone");

module.exports.config = {
  name: "console",
  version: "1.0.0",
  hasPermssion: 3,
  credits: "JRT by bat",
  description: "In log tin nhắn vào console",
  commandCategory: "Hệ Thống",
  usages: "console",
  cooldowns: 0
};

module.exports.handleEvent = async function ({ event, Users }) {
  const { threadID, senderID, body } = event;
  const threadData = global.data.threadData.get(threadID) || {};
  if (threadData.console === true || senderID == global.data.botID) return;

  const threadInfo = global.data.threadInfo.get(threadID);
  const nameBox = threadInfo?.threadName || "Tên nhóm không xác định";
  const nameUser = await Users.getNameUser(senderID);
  const msg = body || "Ảnh, video hoặc kí tự đặc biệt";
  const time = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss - DD/MM/YYYY");

  console.log(`\n[ CONSOLE LOG ]
• Nhóm     : ${nameBox}
• ID nhóm  : ${threadID}
• Người gửi: ${nameUser}
• ID user  : ${senderID}
• Nội dung : ${msg}
• Thời gian: ${time}
----------------------------`);
};

module.exports.run = async function () {};