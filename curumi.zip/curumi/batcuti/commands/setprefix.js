const fs = require("fs");
const path = require("path");

module.exports.config = {
  name: "setprefix",
  version: "1.0.1",
  hasPermssion: 1,
  credits: "mod by ChatGPT",
  description: "Đổi prefix nhóm thông qua reaction",
  commandCategory: "Tiện ích",
  usages: "[prefix/reset]",
  cooldowns: 2,
  usePrefix: true
};

module.exports.run = async ({ api, event, args, Threads }) => {
  const { threadID, messageID, senderID } = event;
  if (typeof args[0] === "undefined")
    return api.sendMessage(`⚠️ Vui lòng nhập prefix mới để thay đổi prefix của nhóm`, threadID, messageID);

  const prefix = args[0].trim();

  if (!prefix)
    return api.sendMessage(`⚠️ Prefix không hợp lệ, vui lòng thử lại.`, threadID, messageID);

  if (prefix.toLowerCase() === "reset") {
    let data = (await Threads.getData(threadID)).data || {};
    data["PREFIX"] = global.config.PREFIX;
    await Threads.setData(threadID, { data });
    await global.data.threadData.set(String(threadID), data);

    const uid = api.getCurrentUserID();
    api.changeNickname(`${global.config.BOTNAME}`, threadID, uid);

    return api.sendMessage(`☑️ Đã reset prefix về mặc định: ${global.config.PREFIX}`, threadID, messageID);
  } else {
    return api.sendMessage(
      `📝 Bạn đang yêu cầu set prefix mới: ${prefix}\n👉 Reaction tin nhắn này để xác nhận`,
      threadID,
      (error, info) => {
        global.client.handleReaction.push({
          name: "setprefix",
          messageID: info.messageID,
          author: senderID,
          PREFIX: prefix
        });
      },
      messageID
    );
  }
};

module.exports.handleReaction = async function ({ api, event, Threads, handleReaction }) {
  try {
    if (event.userID != handleReaction.author) return;

    const { threadID, messageID } = event;
    let data = (await Threads.getData(String(threadID))).data || {};
    const prefix = handleReaction.PREFIX;

    data["PREFIX"] = prefix;
    await Threads.setData(threadID, { data });
    await global.data.threadData.set(String(threadID), data);

    api.unsendMessage(handleReaction.messageID);
    api.changeNickname(`${global.config.BOTNAME}`, threadID, event.senderID);
    return api.sendMessage(`☑️ Đã thay đổi prefix của nhóm thành: ${prefix}`, threadID, messageID);
  } catch (e) {
    console.error("❌ Lỗi khi xử lý reaction setprefix:", e);
  }
};