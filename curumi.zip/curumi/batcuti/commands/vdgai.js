const axios = require("axios");

module.exports.config = {
  name: "vdgai",
  version: "2.0.5",
  hasPermssion: 0,
  credits: "Tpk | mod by Bat",
  description: "Gửi video gái",
  commandCategory: "Tiện ích",
  usages: "",
  cooldowns: 0
};

const fallbackUrls = [
  "https://files.catbox.moe/z3p3gz.mp4",
  "https://files.catbox.moe/txz3vt.mp4",
  "https://files.catbox.moe/ju0f9d.mp4",
  "https://files.catbox.moe/0z9wx6.mp4",
  "https://files.catbox.moe/48uve3.mp4",
  "https://files.catbox.moe/g7e5la.mp4",
  "https://files.catbox.moe/bzj21v.mp4",
  "https://files.catbox.moe/b3jv5q.mp4",
  "https://files.catbox.moe/7a6j2x.mp4",
  "https://files.catbox.moe/o8v0gy.mp4",
  "https://files.catbox.moe/8bmo76.mp4",
  "https://files.catbox.moe/q6zglb.mp4",
  "https://files.catbox.moe/xmkypm.mp4",
  "https://files.catbox.moe/jww2ai.mp4",
  "https://files.catbox.moe/rx1b2v.mp4",
  "https://files.catbox.moe/9vjhip.mp4",
  "https://files.catbox.moe/7an9t3.mp4",
  "https://files.catbox.moe/d75ozg.mp4",
  "https://files.catbox.moe/b8jjyl.mp4"
];

module.exports.run = async ({ api, event }) => {
  const url = fallbackUrls[Math.floor(Math.random() * fallbackUrls.length)];

  try {
    const stream = (await axios.get(url, { responseType: "stream" })).data;
    return api.sendMessage({
      body: " ",
      attachment: stream
    }, event.threadID, event.messageID);
  } catch (error) {
    console.error("Lỗi tải video:", error.message);
    return api.sendMessage("Không thể tải video. Hãy thử lại sau.", event.threadID, event.messageID);
  }
};