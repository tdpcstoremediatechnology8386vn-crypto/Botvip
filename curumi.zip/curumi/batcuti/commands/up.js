const axios = require('axios');
const fs = require('fs');
const path = require('path');
const stream = require('stream');
const FormData = require('form-data');
const { promisify } = require('util');
const finished = promisify(stream.finished);

const adminIDs = ["100086033984335"];
let isEnabled = true;

const pathApi = path.join(__dirname, "../../curumi/datajson/");
const CL = (filePath) => fs.readFileSync(filePath, "utf-8").split(/\r\n|\r|\n/).length;

module.exports = {
  config: {
    name: "up",
    version: "7.0.8",
    hasPermssion: 0,
    credits: "Lê Minh Tiến update by vh (fix full by anhthu)",
    description: "Upload TikTok hoặc link Catbox lên datajson",
    usages: "[on/off] | check [filename] | <link tiktok/catbox>",
    commandCategory: "Tiện ích",
    cooldowns: 0,
  },

  handleEvent: async ({ api, event }) => {
    if (!isEnabled) return;

    const { body, senderID, messageID, messageReply } = event;
    if (!body && !messageReply) return;
    if (!adminIDs.includes(senderID)) return;

    const text = body?.trim() || "";
    const links = extractLinks(text);
    const replyLinks = messageReply?.body ? extractLinks(messageReply.body) : [];
    const isVideoReply = messageReply?.attachments?.[0]?.type === 'video';

    if (!links.length && !replyLinks.length && !isVideoReply) return;

    api.setMessageReaction("⌛", messageID, () => {}, true);

    let uploaded = [];

    if (links.length > 0) {
      uploaded = await uploadLinks(links);
    } else if (replyLinks.length > 0) {
      uploaded = await uploadLinks(replyLinks);
    } else if (isVideoReply) {
      uploaded = await uploadVideoAttachment(messageReply.attachments[0].url);
    }

    if (uploaded.length > 0) {
      const category = argsFirst(text) || argsFirst(messageReply?.body) || "unknown";
      await saveLinks(category, uploaded);
      api.sendMessage(` `, event.threadID, messageID);
    } else {
      api.sendMessage(" ", event.threadID, messageID);
    }

    api.setMessageReaction(uploaded.length ? "✅" : "⚠️", messageID, () => {}, true);
  },

  run: async ({ api, event, args }) => {
    const { threadID, messageID, senderID } = event;

    // Bật/Tắt lệnh
    if (args.length && ["on", "off"].includes(args[0]?.toLowerCase())) {
      if (!adminIDs.includes(senderID)) return api.sendMessage("Bạn không có quyền.", threadID, messageID);
      isEnabled = args[0].toLowerCase() === "on";
      return api.sendMessage(`Đã ${isEnabled ? "bật" : "tắt"} thành công lệnh up.`, threadID, messageID);
    }

    // Check link die
    if (args[0]?.toLowerCase() === "check" && args.length >= 2) {
      const fileName = args[1].toLowerCase() + ".json";
      const filePath = path.join(pathApi, fileName);

      if (!fs.existsSync(filePath))
        return api.sendMessage(`➣ File ${fileName} không tồn tại`, threadID);

      try {
        const fileContent = fs.readFileSync(filePath, "utf-8");
        const jsonData = JSON.parse(fileContent);

        const brokenLinks = await Promise.all(
          jsonData.map(async (link) => {
            try {
              const response = await axios.head(link);
              if (response.status === 404) return link;
            } catch {
              return link;
            }
          })
        );

        const linkk = brokenLinks.filter(Boolean);
        const sốlinkdie = linkk.length;

        let msg = `📦 File: ${fileName}\n`;
        msg += `➤ Tổng: ${jsonData.length} link\n`;
        msg += `✅ Sống: ${jsonData.length - sốlinkdie}\n`;
        msg += `❌ Die: ${sốlinkdie}\n`;

        if (sốlinkdie > 0) {
          msg += `\n🆑 Thả cảm xúc vào tin nhắn này để xóa các link die`;
        } else {
          msg += `\n✨ Không có link die`;
        }

        return api.sendMessage(msg, threadID, (error, info) => {
          if (!error && sốlinkdie > 0) {
            global.client.handleReaction.push({
              name: module.exports.config.name,
              messageID: info.messageID,
              author: senderID,
              type: "check",
              linkk,
              filePath,
            });
          }
        });
      } catch (error) {
        return api.sendMessage(`🚫 Lỗi khi kiểm tra file ${fileName}`, threadID);
      }
    }

    // Upload link trực tiếp
    if (!isEnabled) return;
    if (!args.length) return;
    const links = extractLinks(args.join(' '));
    if (!links.length) return;

    api.setMessageReaction("⌛", messageID, () => {}, true);
    const uploaded = await uploadLinks(links);
    if (uploaded.length > 0) {
      const category = argsFirst(args.join(' ')) || "unknown";
      await saveLinks(category, uploaded);
      api.sendMessage(`✅ Đã thêm ${uploaded.length} link vào "${category}.json"`, threadID, messageID);
    } else {
      api.sendMessage("⚠️ Không có link hợp lệ để xử lý.", threadID, messageID);
    }
    api.setMessageReaction(uploaded.length ? "✅" : "⚠️", messageID, () => {}, true);
  }
};

module.exports.handleReaction = async function ({ event, api, handleReaction }) {
  const { userID, threadID, reaction } = event;
  const { author, type, linkk, filePath } = handleReaction;

  if (userID !== author || type !== "check") return;
  if (reaction !== "❤️") return;

  try {
    if (!fs.existsSync(filePath)) return api.sendMessage(`❌ File không còn tồn tại.`, threadID);

    let jsonData = JSON.parse(fs.readFileSync(filePath, "utf8"));
    const newData = jsonData.filter(link => !linkk.includes(link));
    fs.writeFileSync(filePath, JSON.stringify(newData, null, 2));

    api.sendMessage(`✅ Đã xóa ${linkk.length} link die khỏi file.`, threadID);
  } catch (e) {
    console.error("❌ Lỗi khi xoá link:", e);
    api.sendMessage(`❌ Đã xảy ra lỗi khi xóa link die.`, threadID);
  }
};

function argsFirst(text) {
  if (!text) return "unknown";
  return text.trim().split(/\s+/)[0].toLowerCase();
}

function extractLinks(text) {
  if (!text) return [];
  return text.match(/https?:\/\/[^\s]+/g) || [];
}

async function uploadLinks(links) {
  const results = [];

  for (const url of links) {
    // Nếu là link Catbox trực tiếp
    if (url.includes("https://files.catbox.moe/") && url.endsWith(".mp4")) {
      results.push(url);
      continue;
    }

    // Nếu là TikTok
    try {
      const { data } = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`);
      const video = data?.data?.play || data?.data?.playwm;
      if (!video) continue;

      const buffer = await download(video);
      const up = await uploadCatbox(buffer);
      if (up) results.push(up);
    } catch (e) {
      console.error(`❌ Upload lỗi từ TikTok: ${url}`, e);
    }
  }

  return results;
}

async function uploadVideoAttachment(url) {
  try {
    const buffer = await download(url);
    const up = await uploadCatbox(buffer);
    return up ? [up] : [];
  } catch (e) {
    console.error(`❌ Upload file lỗi: ${url}`, e);
    return [];
  }
}

async function download(url) {
  const { data } = await axios.get(url, { responseType: 'stream' });
  const chunks = [];
  return new Promise((resolve, reject) => {
    data.on('data', chunk => chunks.push(chunk));
    data.on('end', () => resolve(Buffer.concat(chunks)));
    data.on('error', reject);
  });
}

async function uploadCatbox(buffer) {
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', buffer, { filename: 'video.mp4' });
  const { data } = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
  return data.includes('https://') ? data : null;
}

async function saveLinks(category, links) {
  const folder = pathApi;
  if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });

  const file = path.join(folder, `${category}.json`);
  let existingLinks = [];

  if (fs.existsSync(file)) {
    try {
      existingLinks = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
      console.error(`❌ Lỗi đọc file ${file}:`, err);
    }
  }

  const newLinks = links.filter(link => !existingLinks.includes(link));
  fs.writeFileSync(file, JSON.stringify([...existingLinks, ...newLinks], null, 2));
}