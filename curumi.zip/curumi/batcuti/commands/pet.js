const adminIDs = ["100086033984335"];
const fs = require("fs-extra");
const path = require("path");

const dataDir = path.join(__dirname, "data");
fs.ensureDirSync(dataDir);
const dataPath = path.join(dataDir, "pet.json");
const resetRequestsPath = path.join(dataDir, "pet_reset_requests.json");

if (!fs.existsSync(dataPath)) fs.writeJsonSync(dataPath, {});
if (!fs.existsSync(resetRequestsPath)) fs.writeJsonSync(resetRequestsPath, []);

function getData() {
  try {
    return fs.readJsonSync(dataPath);
  } catch (e) {
    console.error("Lỗi đọc file pet.json:", e);
    return {};
  }
}

function saveData(data) {
  fs.writeJsonSync(dataPath, data, { spaces: 2 });
}

function getResetRequests() {
  try {
    return fs.readJsonSync(resetRequestsPath);
  } catch (e) {
    console.error("Lỗi đọc file pet_reset_requests.json:", e);
    return [];
  }
}

function saveResetRequests(requests) {
  fs.writeJsonSync(resetRequestsPath, requests, { spaces: 2 });
}

const petTypes = {
  cún: { emoji: "🐶", skill: "Sủa ầm ầm", evolveLevel: 10, evolveTo: "wolf", maxHp: 120 },
  mèo: { emoji: "🐱", skill: "Hồi máu", evolveLevel: 8, evolveTo: "lion", maxHp: 110 },
  rồng: { emoji: "🐉", skill: "Thở lửa", evolveLevel: 15, evolveTo: "dragon_king", maxHp: 150 },
  thỏ: { emoji: "🐰", skill: "Nhanh nhẹn", evolveLevel: 7, evolveTo: "rabbit_king", maxHp: 100 },
  sói: { emoji: "🐺", skill: "Cắn mạnh", evolveLevel: 0, evolveTo: null, maxHp: 140 },
  sư_tử: { emoji: "🦁", skill: "Gầm rống", evolveLevel: 0, evolveTo: null, maxHp: 130 },
  vua_rồng: { emoji: "🐲", skill: "Phun lửa lớn", evolveLevel: 0, evolveTo: null, maxHp: 180 },
  vua_thỏ: { emoji: "🐇", skill: "Tăng tốc", evolveLevel: 0, evolveTo: null, maxHp: 120 }
};

const foodList = {
  thịt: { name: "🥩 Thịt", heal: 20, cost: 50 },
  cá: { name: "🐟 Cá", heal: 15, cost: 30 },
  rau: { name: "🥬 Rau", heal: 10, cost: 15 }
};

const COIN_DAILY = 100;
const COOLDOWN_DAILY = 24 * 60 * 60 * 1000;
const COOLDOWN_FEED = 24 * 60 * 60 * 1000;
const COOLDOWN_PVP = 60 * 60 * 1000;
const MAX_LEVEL = 10000;
const PET_MESSAGE_INTERVAL = 60 * 60 * 1000;
const CLEANUP_INTERVAL = 12 * 60 * 60 * 1000;

const cuteMessages = {
  cún: [
    "Gâu gâu! Mình đói bụng rồi đó, cho mình ăn đi!",
    "Woof! Bạn là chủ nhân tuyệt vời nhất của mình!",
    "Chủ nhân ơi, mình nhớ bạn quá! Ra chơi với mình đi!",
  ],
  mèo: [
    "Meow~ Bạn có muốn chơi với mình không?",
    "Zzzz... Mình đang ngủ mơ về những món đồ ăn ngon!",
    "Sen ơi, cho mình xin miếng cá đi màaa~",
  ],
  rồng: [
    "Roar! Mình đang tập skill thở lửa đây, có muốn xem không?",
    "Graaawr! Mình đang cảm thấy mạnh mẽ hơn bao giờ hết!",
    "Bạn có thấy mình ngầu hơn mỗi ngày không?",
  ],
  thỏ: [
    "Chít chít... Sao bạn mãi không về chơi với mình?",
    "Mình vừa chạy bộ một vòng quanh nhà đó! Bạn có muốn tham gia không?",
    "Nhảy nhảy... Mình là bé thỏ đáng yêu nhất!",
  ],
  sói: [
    "A hú! Mình đang cảm thấy rất hoang dã hôm nay!",
    "Đêm nay chúng ta đi săn chứ, chủ nhân?",
  ],
  sư_tử: [
    "Gầm rống! Ai là chúa tể muôn loài nào?",
    "Mình đang thống trị lãnh thổ đây, không ai có thể cản được!",
  ],
  vua_rồng: [
    "Ta là Vua Rồng! Ngươi có vâng lời ta không?",
    "Cẩn thận với hơi thở của ta, nó có thể thiêu rụi mọi thứ!",
  ],
  vua_thỏ: [
    "Tăng tốc! Không ai có thể bắt kịp tốc độ của ta!",
    "Ta là vua của những chú thỏ, nhanh nhẹn và thông minh!",
  ],
  chung: [
    "Phew... Hôm nay mình đã tập thể dục rất chăm chỉ!",
    "Ting tong! Có tin nhắn từ mình đây! Bạn có nhớ mình không?",
    "Mlem mlem... Đồ ăn của bạn ngon quá!",
    "Nào, chúng ta đi dạo một vòng nhé?",
    "Mình đang rất vui khi có bạn ở đây!",
  ]
};

let petMessageInterval = null;
let cleanupInterval = null;

async function sendRandomPetMessage(api) {
  const data = getData();
  for (const senderID in data) {
    const user = data[senderID];
    if (user.pet && user.threadID && user.isValidThread !== false) {
      const petTypeKey = user.pet;
      const petInfo = petTypes[petTypeKey];

      const messagesForPet = cuteMessages[petTypeKey] || cuteMessages.chung;
      const randomMessage = messagesForPet[Math.floor(Math.random() * messagesForPet.length)];
      const petName = user.name || "Pet của bạn";
      try {
        await api.sendMessage(`${petInfo.emoji} ${petName}: ${randomMessage}`, user.threadID);
      } catch (error) {
        console.error(`Không thể gửi tin nhắn cho ${senderID} trong thread ${user.threadID}:`, error);
        if (error.message.includes("Cannot send message to this thread") || error.message.includes("invalid thread id") || error.message.includes("is not a member")) {
          console.warn(`Đánh dấu thread ${user.threadID} của người dùng ${senderID} là không hợp lệ.`);
          user.isValidThread = false;
          saveData(data);
        }
      }
    }
  }
}

async function cleanupInvalidThreads() {
  const data = getData();
  let changed = false;
  for (const senderID in data) {
    const user = data[senderID];
    if (user.isValidThread === false) {
      console.log(`Đang xóa dữ liệu pet của người dùng ${senderID} (thread ${user.threadID}) do bot đã bị out/kick.`);
      delete data[senderID];
      changed = true;
    }
  }
  if (changed) {
    saveData(data);
    console.log("Đã hoàn tất dọn dẹp dữ liệu các thread không hợp lệ.");
  }
}

module.exports = {
  config: {
    name: "pet",
    version: "4.9",
    hasPermission: 0,
    credits: "Bat",
    description: "Game nuôi pet online full tính năng",
    commandCategory: "game",
    usages: "",
    cooldowns: 3,
  },

  onLoad: function({ api }) {
    if (petMessageInterval) clearInterval(petMessageInterval);
    petMessageInterval = setInterval(() => sendRandomPetMessage(api), PET_MESSAGE_INTERVAL);

    if (cleanupInterval) clearInterval(cleanupInterval);
    cleanupInterval = setInterval(cleanupInvalidThreads, CLEANUP_INTERVAL);
    console.log("load thành công toàn bộ thông tin người nuôi pet 🐾👤.");

  },

  run: async function ({ api, event, args }) {
    const { senderID, threadID, messageID } = event;
    const data = getData();
    let resetRequests = getResetRequests();

    if (!data[senderID]) {
      data[senderID] = { pet: null, name: null, hp: 0, maxHp: 100, level: 1, coin: 100, lastFed: 0, bag: {}, lastDaily: 0, lastPvp: 0, win: 0, lose: 0, threadID: threadID, isValidThread: true };
      saveData(data);
    } else {
      if (data[senderID].threadID !== threadID || data[senderID].isValidThread === false) {
        data[senderID].threadID = threadID;
        data[senderID].isValidThread = true;
        saveData(data);
      }
    }
    const user = data[senderID];
    const sub = args[0]?.toLowerCase();
    const saveAndReact = (reaction = "✅") => {
      saveData(data);
      api.setMessageReaction(reaction, messageID, () => { }, true);
    };
    if (sub === "data") {
      if (!adminIDs.includes(senderID)) {
        return api.sendMessage("❌ Bạn không có quyền sử dụng lệnh này.", threadID, messageID);
      }
      const targetUID = args[1];
      if (!targetUID) {
        return api.sendMessage("⚠️ Vui lòng nhập UID người dùng bạn muốn kiểm tra dữ liệu.", threadID, messageID);
      }
      if (data[targetUID]) {
        return api.sendMessage(`🔍 Dữ liệu người dùng UID ${targetUID}:\n\n${JSON.stringify(data[targetUID], null, 2)}`, threadID, messageID);
      } else {
        return api.sendMessage(`❌ Không tìm thấy dữ liệu của người dùng có UID ${targetUID}.`, threadID, messageID);
      }
    }
    if (sub === "trả") {
      if (!user.pet) {
        return api.sendMessage("🐣 Bạn chưa có pet để reset!", threadID, messageID);
      }
      const existingRequest = resetRequests.find(req => req.senderID === senderID);
      if (existingRequest) {
        return api.sendMessage("⏳ Bạn đã có yêu cầu reset pet đang chờ duyệt. Vui lòng chờ admin xử lý.", threadID, messageID);
      }
      let userName = senderID;
      try {
        const userInfo = await api.getUserInfo(senderID);
        if (userInfo && userInfo[senderID] && userInfo[senderID].name) {
          userName = userInfo[senderID].name;
        }
      } catch (error) {
        console.error("Lỗi khi lấy tên người dùng:", error);
      }
      resetRequests.push({ senderID, userName, threadID, timestamp: Date.now() });
      saveResetRequests(resetRequests);
      saveAndReact("⏰");
      return api.sendMessage("⏳ Yêu cầu reset pet của bạn đã được gửi và đang chờ admin duyệt. Vui lòng chờ phản hồi.", threadID, messageID);
    }
    if (sub === "listrset") {
      if (!adminIDs.includes(senderID)) {
        return api.sendMessage("❌ Bạn không có quyền sử dụng lệnh này.", threadID, messageID);
      }
      if (resetRequests.length === 0) {
        return api.sendMessage("📝 Hiện không có yêu cầu reset pet nào đang chờ duyệt.", threadID, messageID);
      }
      const action = args[1]?.toLowerCase();
      const index = parseInt(args[2]);
      if (!action) {
        let msg = "📝 Danh sách yêu cầu reset pet đang chờ duyệt:\n\n";
        resetRequests.forEach((req, i) => {
          msg += `${i + 1}. Tên: ${req.userName || "Không rõ"}\n`;
        });
        msg += "\n👉 Để duyệt, gõ: \`pet dsrset duyệt [số thứ tự]\`\n👉 Để từ chối, gõ: \`pet dsrset không duyệt [số thứ tự]\`";
        return api.sendMessage(msg, threadID, messageID);
      }
      if (isNaN(index) || index <= 0 || index > resetRequests.length) {
        return api.sendMessage("❗ Số thứ tự không hợp lệ. Vui lòng nhập đúng số thứ tự trong danh sách.", threadID, messageID);
      }
      const requestIndex = index - 1;
      const requestToProcess = resetRequests[requestIndex];
      if (action === "duyệt") {
        if (data[requestToProcess.senderID]) {
          delete data[requestToProcess.senderID];
          saveData(data);
          api.sendMessage(`✅ Yêu cầu reset pet của người dùng ${requestToProcess.userName} đã được duyệt thành công. Dữ liệu pet của họ đã được xóa.`, threadID, messageID);
          try {
            await api.sendMessage("🎉 Pet của bạn đã được reset thành công bởi admin! Bạn có thể nhận nuôi pet mới.", requestToProcess.threadID);
          } catch (error) {
            console.error(`Không thể gửi tin nhắn thông báo reset cho ${requestToProcess.senderID}:`, error);
          }
        } else {
          api.sendMessage(`❗ Không tìm thấy dữ liệu pet của người dùng ${requestToProcess.userName}. Có thể họ đã không còn pet.`, threadID, messageID);
        }
        resetRequests.splice(requestIndex, 1);
        saveResetRequests(resetRequests);
        saveAndReact("✅");
      } else if (action === "không") {
        resetRequests.splice(requestIndex, 1);
        saveResetRequests(resetRequests);
        saveAndReact("❌");
        api.sendMessage(`❌ Yêu cầu reset pet của người dùng ${requestToProcess.userName} đã bị từ chối.`, threadID, messageID);
        try {
          await api.sendMessage("😔 Yêu cầu reset pet của bạn đã bị admin từ chối. Vui lòng liên hệ admin nếu có thắc mắc.", requestToProcess.threadID);
        } catch (error) {
          console.error(`Không thể gửi tin nhắn thông báo từ chối reset cho ${requestToProcess.senderID}:`, error);
        }
      } else {
        return api.sendMessage("❗ Hành động không hợp lệ. Chỉ chấp nhận 'accept' hoặc 'decline'.", threadID, messageID);
      }
      return;
    }
    if (sub === "adopt") {
      const type = args[1]?.toLowerCase();
      if (!petTypes[type]) {
        return api.sendMessage(
          `🐾 Các loại pet có thể nuôi:\n${Object.keys(petTypes).filter(k => !k.includes("_")).map(p => `- ${p}: ${petTypes[p].emoji}`).join("\n")}\n\n👉 Gõ: pet adopt [loại] hoặc pet list để xem danh sách`,
          threadID,
          messageID
        );
      }
      if (user.pet) return api.sendMessage("❌ Bạn đã có pet rồi!", threadID, messageID);
      user.pet = type;
      user.hp = 80;
      user.maxHp = petTypes[type].maxHp;
      user.lastFed = Date.now();
      saveAndReact(petTypes[type].emoji);
      return api.sendMessage(`🎉 Bạn đã nhận nuôi một ${type.toUpperCase()} ${petTypes[type].emoji}!\nDùng "pet name [tên]" để đặt tên.`, threadID, messageID);
    }
    if (sub === "tên") {
      const newName = args.slice(1).join(" ");
      if (!newName) return api.sendMessage("✏️ Gõ: pet name [tên mới]", threadID, messageID);
      if (!user.pet) return api.sendMessage("🐣 Bạn chưa có pet! Gõ: pet adopt [loại]", threadID, messageID);
      user.name = newName;
      saveAndReact("✏️");
      return api.sendMessage(`✅ Đặt tên thành công: ${newName}`, threadID, messageID);
    }
    if (sub === "mua") {
      const item = args[1]?.toLowerCase();
      if (!foodList[item]) {
        return api.sendMessage(
          `🛒 Đồ ăn hiện có:\n${Object.entries(foodList).map(([k, v]) => `- ${k}: ${v.name} (${v.cost} coin)`).join("\n")}\n\n👉 Gõ: pet buy [tên đồ ăn]`,
          threadID,
          messageID
        );
      }
      if (user.coin < foodList[item].cost) return api.sendMessage("💸 Bạn không đủ coin!", threadID, messageID);
      user.coin -= foodList[item].cost;
      user.bag[item] = (user.bag[item] || 0) + 1;
      saveAndReact("🛍️");
      return api.sendMessage(`🛍️ Đã mua 1 ${foodList[item].name}.\n💰 Số dư còn lại: ${user.coin} coin.`, threadID, messageID);
    }
    if (sub === "ăn") {
      const item = args[1]?.toLowerCase();
      if (!item || !foodList[item]) {
        return api.sendMessage(`🍱 Gõ: pet feed [tên đồ ăn]\n🎒 Túi: ${Object.entries(user.bag).map(([k, v]) => `${foodList[k].name} x${v}`).join(", ") || "Trống"}`, threadID, messageID);
      }
      if (!adminIDs.includes(senderID) && (user.bag[item] || 0) < 1) {
        return api.sendMessage(`❌ Không có ${foodList[item].name} trong túi!`, threadID, messageID);
      }
      if (!user.pet) return api.sendMessage("🐣 Bạn chưa có pet! Gõ: pet adopt [loại]", threadID, messageID);
      if (!adminIDs.includes(senderID) && Date.now() - user.lastFed < COOLDOWN_FEED) {
        const timeLeft = ((COOLDOWN_FEED - (Date.now() - user.lastFed)) / (1000 * 60 * 60)).toFixed(1);
        return api.sendMessage(`ăn gì lắm vậy má đợi ${timeLeft} giờ đi rồi tao ăn,mệt!!`, threadID, messageID);
      }
      const heal = foodList[item].heal;
      user.hp = Math.min(user.maxHp, user.hp + heal);
      if (!adminIDs.includes(senderID)) {
        user.bag[item] -= 1;
      }
      user.lastFed = Date.now();
      let leveledUp = false;
      if (user.hp === user.maxHp) {
        if (adminIDs.includes(senderID) || user.level < MAX_LEVEL) {
          user.level++;
          leveledUp = true;
          const petInfo = petTypes[user.pet];
          if (petInfo.evolveTo && user.level >= petInfo.evolveLevel) {
            user.pet = petInfo.evolveTo;
            user.maxHp = petTypes[petInfo.evolveTo].maxHp;
            user.hp = user.maxHp;
            saveAndReact(petTypes[user.pet].emoji);
            return api.sendMessage(`🎉 Pet của bạn đã tiến hóa thành ${user.pet.toUpperCase()} ${petTypes[user.pet].emoji}!\nLevel hiện tại: ${user.level}`, threadID, messageID);
          }
        } else if (adminIDs.includes(senderID)) {
          user.level++;
          leveledUp = true;
        }
      }
      saveAndReact("🍱");
      return api.sendMessage(`${foodList[item].name} đã được ăn.\n❤️ HP: ${user.hp}/${user.maxHp}\n⭐ Level: ${user.level}`, threadID, messageID);
    }
    if (sub === "info") {
      if (!user.pet) return api.sendMessage("🐣 Bạn chưa có pet. Gõ: pet adopt [loại]", threadID, messageID);
      const petInfo = petTypes[user.pet];
      const bag = Object.entries(user.bag).map(([k, v]) => `${foodList[k]?.name || k} x${v}`).join(", ") || "Trống";
      const petName = user.name || "(Chưa đặt tên)";
      return api.sendMessage(
        `🐾 Pet của bạn:\n` +
        `- Loại: ${user.pet.toUpperCase()} ${petInfo.emoji}\n` +
        `- Tên: ${petName}\n` +
        `- HP: ${user.hp}/${user.maxHp}\n` +
        `- Level: ${user.level}\n` +
        `- Skill: ${petInfo.skill}\n` +
        `- Túi đồ ăn: ${bag}\n` +
        `- Coin: ${user.coin}\n` +
        `- Thắng: ${user.win}\n- Thua: ${user.lose}`,
        threadID,
        messageID
      );
    }
    if (sub === "check") {
      if (!adminIDs.includes(senderID)) {
        return api.sendMessage("❌ Bạn không có quyền sử dụng lệnh này. Lệnh này chỉ dành cho admin.", threadID, messageID);
      }
      const allPetOwners = Object.entries(data)
        .filter(([uid, u]) => u.pet);
      if (allPetOwners.length === 0) {
        return api.sendMessage("🐾 Hiện tại không có người dùng nào đang nuôi pet trong hệ thống.", threadID, messageID);
      }
      let msg = "📝 Danh sách tất cả người nuôi pet:\n__________\n";
      for (let i = 0; i < allPetOwners.length; i++) {
        const [uid, u] = allPetOwners[i];
        const petInfo = petTypes[u.pet] || {};
        const petName = u.name || "(Chưa đặt tên)";
        const bag = Object.entries(u.bag).map(([k, v]) => `${foodList[k]?.name || k} x${v}`).join(", ") || "Trống";
        let userName = `UID: ${uid}`;
        try {
          const userInfo = await api.getUserInfo(uid);
          if (userInfo && userInfo[uid] && userInfo[uid].name) {
            userName = `Tên: ${userInfo[uid].name}`;
          }
        } catch (error) {
          console.error(`Không thể lấy tên người dùng cho UID ${uid}:`, error);
        }
        msg += `${i + 1}. ${userName}\n` +
          `Pet: ${petName} (${u.pet.toUpperCase()} ${petInfo.emoji || ""})\n` +
          `HP: ${u.hp}/${u.maxHp} | Level: ${u.level}\n` +
          `Coin: ${u.coin}\nThắng: ${u.win}\nThua: ${u.lose}\n` +
          `Túi: ${bag}\n____________\n`;
      }
      return api.sendMessage(msg, threadID, messageID);
    }
    if (sub === "tặng") {
      const uid = args[1];
      const item = args[2]?.toLowerCase();
      if (!uid || !item) return api.sendMessage("🎁 Gõ: pet gift [uid] [tên đồ ăn]", threadID, messageID);
      if (!foodList[item]) return api.sendMessage("❌ Đồ ăn không hợp lệ!", threadID, messageID);
      if ((user.bag[item] || 0) < 1) return api.sendMessage("❌ Bạn không có đồ ăn này để tặng!", threadID, messageID);
      if (!data[uid]) return api.sendMessage("❌ Người nhận chưa nuôi pet!", threadID, messageID);
      user.bag[item] -= 1;
      data[uid].bag[item] = (data[uid].bag[item] || 0) + 1;
      saveAndReact("🎁");
      return api.sendMessage(`🎁 Bạn đã tặng 1 ${foodList[item].name} cho người dùng ${uid}`, threadID, messageID);
    }
    if (sub === "đánh") {
      const uid = args[1];
      if (!uid) return api.sendMessage("⚔️ Gõ: pet pvp [uid]", threadID, messageID);
      if (!data[uid] || !data[uid].pet) return api.sendMessage("❌ Người chơi này chưa nuôi pet!", threadID, messageID);
      if (!user.pet) return api.sendMessage("🐣 Bạn chưa có pet!", threadID, messageID);
      if (!adminIDs.includes(senderID) && Date.now() - user.lastPvp < COOLDOWN_PVP) {
        const timeLeft = ((COOLDOWN_PVP - (Date.now() - user.lastPvp)) / 60000).toFixed(1);
        return api.sendMessage(`⏳ Bạn phải chờ ${timeLeft} phút để pvp tiếp!`, threadID, messageID);
      }
      user.lastPvp = Date.now();
      const userPower = user.level * (user.hp / user.maxHp) * (Math.random() + 0.5);
      const opp = data[uid];
      const oppPower = opp.level * (opp.hp / opp.maxHp) * (Math.random() + 0.5);
      let resultMsg = "";
      if (userPower > oppPower) {
        user.win++;
        opp.lose++;
        user.coin += 50;
        resultMsg = `🏆 Bạn đã thắng PvP với người chơi ${uid}!\nBạn nhận được 50 coin!`;
      } else if (userPower < oppPower) {
        user.lose++;
        opp.win++;
        opp.coin += 50;
        resultMsg = `💀 Bạn đã thua PvP với người chơi ${uid}!\nNgười kia nhận 50 coin!`;
      } else {
        resultMsg = "⚔️ PvP hoà nhau, không ai thắng ai!";
      }
      saveAndReact(resultMsg.includes("thắng") ? "🏆" : "💀");
      saveData(data);
      return api.sendMessage(resultMsg, threadID, messageID);
    }
    if (sub === "daily") {
      if (Date.now() - user.lastDaily < COOLDOWN_DAILY) {
        const timeLeft = Math.floor((COOLDOWN_DAILY - (Date.now() - user.lastDaily)) / 3600000);
        return api.sendMessage(`Sao mà mày tham quá vậy nhận free mà hay ấy quá trờ ${timeLeft} giờ nữa để nhận tiếp,nghe chưa 😈.`, threadID, messageID);
      }
      user.lastDaily = Date.now();
      let dailyAmount = COIN_DAILY;
      if (adminIDs.includes(senderID)) {
        dailyAmount = 50000;
      }
      user.coin += dailyAmount;
      saveAndReact("💰");
      return api.sendMessage(`Tao bố thí cho mày ${dailyAmount} coin đó ><`, threadID, messageID);
    }
    if (sub === "list") {
      let petListMsg = "🐾 Các loại pet bạn có thể nhận nuôi:\n";
      const adoptablePets = Object.entries(petTypes).filter(([key, value]) => !key.includes("_"));
      if (adoptablePets.length === 0) {
        petListMsg += "Hiện không có pet nào khả dụng để nhận nuôi.";
      } else {
        adoptablePets.forEach(([type, info]) => {
          petListMsg += `- ${type.toUpperCase()} ${info.emoji} (HP: ${info.maxHp})\n`;
        });
        petListMsg += "\nĐể nhận nuôi, gõ: \`pet nhận nuôi [tên_pet]\`";
      }
      return api.sendMessage(petListMsg, threadID, messageID);
    }
    if (sub === "help") {
      const helpMessage = `📚 Hướng dẫn sử dụng lệnh Pet:\n\n` +
        `• pet adopt [loại]: Nhận nuôi một pet mới (ví dụ: \`pet adopt cún\`).\n` +
        `• pet tên [tên mới]: Đặt tên cho pet của bạn (ví dụ: \`pet name Mực\`).\n` +
        `• pet mua [đồ ăn]: Mua đồ ăn cho pet (ví dụ: \`pet buy meat\`).\n` +
        `• pet ăn [đồ ăn]: Cho pet ăn để hồi HP và lên cấp (ví dụ: \`pet feed fish\`).\n` +
        `• pet info / pet check: Xem thông tin chi tiết về pet của bạn.\n` +
        `• pet trả: Gửi yêu cầu reset pet của bạn để admin duyệt.\n` +
        `• pet listrset [duyệt/không duyệt] [số thứ tự] (Admin): Duyệt hoặc từ chối yêu cầu trả pet.\n` +
        `• pet tặng [uid] [đồ ăn]: Tặng đồ ăn cho pet của người chơi khác (ví dụ: \`pet tặng 123456789 meat\`).\n` +
        `• pet đánh [uid]: Thách đấu pet của người chơi khác (ví dụ: \`pet pvp 987654321\`).\n` +
        `• pet daily: Nhận tiền thưởng hàng ngày.\n` +
        `• pet list: Xem danh sách các loại pet có thể nhận nuôi.\n` +
        `• pet check (Admin): Xem danh sách tất cả người dùng đang nuôi pet.\n` +
        `• pet data [uid] (Admin): Kiểm tra toàn bộ dữ liệu của người dùng trong pet.json.\n` +
        `• pet help: Hiển thị hướng dẫn sử dụng lệnh này.\n\n` +
        `Chúc bạn chơi game vui vẻ! 🎉`;
      return api.sendMessage(helpMessage, threadID, messageID);
    }
    return api.sendMessage(
      `🐾 Lệnh không hợp lệ. Gõ: \`pet help\` để xem hướng dẫn sử dụng.`,
      threadID,
      messageID
    );

  }
};
