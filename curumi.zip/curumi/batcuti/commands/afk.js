module.exports.config = {
  name: "afk",
  version: "1.0.0",
  hasPermssion: 1,
  credits: "D-Jukie (làm gọn lại: GPT)",
  description: "AFK!",
  commandCategory: "Admin",
  usages: "afk + lí do",
  cooldowns: 5
};

module.exports.run = async ({ event, api, args }) => {
  const { threadID, messageID, senderID } = event;
  if (!global.afk) global.afk = new Map();
  const thread = global.afk.get(threadID) || { v: [] };
  const reason = args.join(" ") || "Không có lí do";

  thread.v.push({ c: senderID, r: reason, p: 1, v: [] });
  global.afk.set(threadID, thread);

  return api.sendMessage(`Đã bật afk ✅\n📝 Lý do: ${reason}`, threadID, messageID);
};

module.exports.handleEvent = async ({ event, api, Users }) => {
  const { threadID, messageID, senderID, body, mentions } = event;
  if (!global.afk || !global.afk.has(threadID)) return;

  const thread = global.afk.get(threadID);
  const mentionIDs = Object.keys(mentions || {});

  for (const id of mentionIDs) {
    const afkUser = thread.v.find(u => u.c === id);
    if (afkUser) {
      afkUser.v.push({ c: senderID, y: body });
      const name = (await Users.getData(id)).name;
      api.sendMessage(`${name} đang bận: ${afkUser.r}`, threadID, messageID);
    }
  }

  const userAFK = thread.v.find(u => u.c === senderID);
  if (userAFK) {
    if (userAFK.p === 0) {
      const tagged = await Promise.all(userAFK.v.map(async tag => {
        const name = (await Users.getData(tag.c)).name;
        return `👤 ${name}\n💬 ${tag.y}`;
      }));
      const msg = `Chào mừng bạn quay trở lại!\nCó ${userAFK.v.length} người đã tag bạn:\n\n${tagged.join("\n\n")}`;

      thread.v = thread.v.filter(u => u.c !== senderID);
      global.afk.set(threadID, thread);
      return api.sendMessage(msg, threadID, messageID);
    }
    userAFK.p = 0;
    global.afk.set(threadID, thread);
  }
};