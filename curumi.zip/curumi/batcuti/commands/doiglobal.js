module.exports = {
  config: {
    name: "doiglobal",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Bat",
    description: "Đổi nguồn video đang dùng trong lệnh thính",
    commandCategory: "Admin",
    usages: "[vdgai | anime | vdbat | vdcos | ...]",
    cooldowns: 5,
  },

  run: async ({ api, event, args }) => {
    const { threadID, messageID } = event;

    if (!args[0]) {
      return api.sendMessage(
        `❗ Hãy nhập tên nguồn video cần đổi.\nVí dụ: setvideo anime\nHiện tại đang dùng: ${global.videoSource || "vdgai"}`,
        threadID,
        messageID
      );
    }

    const sourceName = args[0];

    if (!global[sourceName] || !Array.isArray(global[sourceName])) {
      return api.sendMessage(
        `❌ Không tìm thấy global.${sourceName}. Đảm bảo nó tồn tại và là một mảng.`,
        threadID,
        messageID
      );
    }

    global.videoSource = sourceName;

    return api.sendMessage(
      `✅ Đã đổi nguồn video sang: global.${sourceName}`,
      threadID,
      messageID
    );
  },
};