const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const FormData = require("form-data");
const { v4: uuidv4 } = require("uuid");

const dir = path.join(__dirname, "./../../curumi/datajson");
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

// Nhận mọi loại Imgur link
const isImgurLink = (url) => /imgur\.com\/(\w+)/i.test(url);

module.exports = {
  config: {
    name: "catbox",
    commandCategory: "Tiện ích",
    hasPermssion: 0,
    credits: "Lê Minh Tiến - Bat",
    usages: "[reply file hoặc gửi link TikTok/Imgur]",
    description: "Upload lên catbox và lưu link vào JSON theo tên bạn chọn",
    cooldowns: 0,
  },

  run: async function ({ api, event }) {
    const { threadID, messageID, messageReply, senderID, body } = event;
    const send = (msg, cb) => api.sendMessage(msg, threadID, cb, messageID);

    const uploadBufferToCatbox = async (buffer, filename) => {
      const form = new FormData();
      form.append("reqtype", "fileupload");
      form.append("fileToUpload", buffer, { filename });
      const res = await axios.post("https://catbox.moe/user/api.php", form, {
        headers: form.getHeaders(),
      });
      return res.data;
    };

    const streamURL = async (url, ext) => {
      const res = await axios.get(url, { responseType: "arraybuffer" });
      const tmp = path.join(__dirname, `tmp_${uuidv4()}.${ext}`);
      await fs.outputFile(tmp, res.data);
      const buffer = await fs.readFile(tmp);
      await fs.unlink(tmp);
      return buffer;
    };

    const uploadFromURL = async (url, ext = "mp4") => {
      const buffer = await streamURL(url, ext);
      return await uploadBufferToCatbox(buffer, `upload.${ext}`);
    };

    let uploadedLinks = [];

    // ==== TikTok ====
    const links = (body?.match(/https?:\/\/[^\s]+/g) || []);
    const tikTokLinks = links.filter(link => /tiktok\.com|douyin\.com/.test(link));
    const imgurLinks = links.filter(isImgurLink);

    for (const link of tikTokLinks) {
      try {
        const { data } = await axios.post("https://tikwm.com/api/", { url: link }, {
          headers: { "Content-Type": "application/json" }
        });

        const video = data?.data?.play || data?.data?.playwm;
        if (!video) continue;

        const catboxUrl = await uploadFromURL(video, "mp4");
        uploadedLinks.push(catboxUrl);
      } catch (err) {
        console.error("TikTok:", err.message);
      }
    }

    // ==== Imgur ====
    for (const url of imgurLinks) {
      try {
        const match = url.match(/imgur\.com\/(\w+)/i);
        if (!match) continue;

        const id = match[1];
        const extensions = ["mp4", "gif", "jpg", "png"];
        let catboxUrl = null;

        for (const ext of extensions) {
          const directUrl = `https://i.imgur.com/${id}.${ext}`;
          try {
            const buffer = await streamURL(directUrl, ext);
            catboxUrl = await uploadBufferToCatbox(buffer, `upload.${ext}`);
            uploadedLinks.push(catboxUrl);
            break;
          } catch (err) {
            // thử đuôi khác nếu thất bại
          }
        }

        if (!catboxUrl) {
          console.error("❌ Không thể lấy định dạng hợp lệ từ Imgur link:", url);
        }
      } catch (err) {
        console.error("Imgur:", err.message);
      }
    }

    // ==== File Reply ====
    if (messageReply?.attachments?.length > 0) {
      for (const file of messageReply.attachments) {
        try {
          let ext = "jpg";
          if (file.type === "video") ext = "mp4";
          else if (file.type === "audio") ext = "mp3";
          else if (file.type === "animated_image") ext = "gif";
          else if (file.type === "photo") ext = "jpg";

          const res = await axios.get(file.url, { responseType: "arraybuffer" });
          const catboxUrl = await uploadBufferToCatbox(res.data, `upload.${ext}`);
          uploadedLinks.push(catboxUrl);
        } catch (err) {
          console.error("Reply file:", err.message);
        }
      }
    }

    if (uploadedLinks.length === 0) {
      return send("⚠️ Không có nội dung hợp lệ để upload (TikTok / Imgur / file reply).");
    }

    const linkList = uploadedLinks.map((l, i) => `${i + 1}. ${l}`).join("\n");
    const msg = `"${linkList}"`;

    return send(msg, (err, info) => {
      global.client.handleReply.push({
        name: module.exports.config.name,
        messageID: info.messageID,
        author: senderID,
        urls: uploadedLinks
      });
    });
  },

  handleReply: async function ({ api, event, handleReply }) {
    const { threadID, messageID, senderID, body } = event;
    if (senderID !== handleReply.author) return;

    let filename = body.trim().replace(/[^a-zA-Z0-9-_]/g, "_");
    if (!filename) return api.sendMessage("⚠️ Tên không hợp lệ.", threadID, messageID);

    try {
      const filePath = path.join(dir, `${filename}.json`);
      let existing = [];

      if (fs.existsSync(filePath)) {
        existing = await fs.readJSON(filePath);
      }

      const combined = Array.from(new Set([...existing, ...handleReply.urls]));
      await fs.outputJson(filePath, combined, { spaces: 2 });

      api.sendMessage(`✅ Đã lưu link vào: ${filename}.json\n📁 Tổng cộng: ${combined.length} link`, threadID, messageID);
    } catch (err) {
      console.error("Save error:", err);
      api.sendMessage("❌ Lỗi khi lưu file.", threadID, messageID);
    }
  }
};