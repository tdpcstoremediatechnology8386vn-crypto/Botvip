const scdl = require('soundcloud-downloader').default;
const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');
const moment = require("moment-timezone");
const Youtube = require('youtube-search-api');

const searchResults = {};

async function searchTracks(keyword, limit = 5) {
    const searchResult = await scdl.search({
        query: keyword,
        limit: limit,
        resourceType: 'tracks'
    });

    if (!searchResult || !searchResult.collection || searchResult.collection.length === 0) {
        return [];
    }

    return searchResult.collection.map(track => ({
        title: track.title,
        artist: track.user.username,
        duration: formatDuration(track.duration),
        url: track.permalink_url,
        playCount: track.playback_count,
        likeCount: track.likes_count
    }));
}

async function downloadTrack(url) {
    const track = await scdl.getInfo(url);
    const stream = await scdl.downloadFormat(url, 'audio/mpeg');
    const fileName = `${track.user.username} - ${track.title}.mp3`.replace(/[/\\?%*:|"<>]/g, '-');
    const filePath = path.join(__dirname, fileName);

    return new Promise((resolve, reject) => {
        const writeStream = fs.createWriteStream(filePath);
        stream.pipe(writeStream);
        stream.on('end', () => resolve({ ...track, filePath }));
        stream.on('error', reject);
    });
}

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

function formatFileSize(size) {
    const i = Math.floor(Math.log(size) / Math.log(1024));
    return (size / Math.pow(1024, i)).toFixed(2) * 1 + ' ' + ['B', 'KB', 'MB', 'GB', 'TB'][i];
}

async function ytdlv2(url, type, quality) {
    const header = {
        "accept": "/",
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "referer": "https://iloveyt.net/vi2",
    };

    const { data } = await axios.post("https://iloveyt.net/proxy.php", { url }, { headers: header });

    let mediaId = data.api.mediaItems.filter(i => i.type === type).map(i => i.mediaId);
    const randomMediaId = mediaId[Math.floor(Math.random() * mediaId.length)];

    let s = 1, mediaProccess, i = 0;
    while (i++ < 10) {
        const base_url = "s" + s + ".ytcontent.net";
        mediaProccess = await axios.get(`https://${base_url}/v3/${type.toLowerCase()}Process/${data.api.id}/${randomMediaId}/${quality}`);
        if (!mediaProccess.data.error) break;
        s++;
    }

    return {
        fileUrl: mediaProccess.data.fileUrl,
        title: data.api.title,
        channel: data.api.userInfo,
        videoInfo: data.api.mediaStats
    };
}

async function getdl(link, type, quality, outPath) {
    const timestart = Date.now();
    const data = await ytdlv2(link, type, quality);
    if (!data) return null;

    const response = await axios.get(data.fileUrl, { responseType: 'arraybuffer' });
    fs.writeFileSync(outPath, response.data);

    return {
        title: data.title,
        timestart
    };
}

module.exports.config = {
    name: "scl",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "Satoru × Bat & Dong Dev, Mhung , anhthu",
    description: "Tìm kiếm & tải nhạc/video từ SoundCloud hoặc YouTube",
    commandCategory: "Nhạc",
    usages: "[tên bài hát] | thêm từ 'mp3' để lấy âm thanh",
    cooldowns: 5,
    aliases: ["yt"],
    hasPrefix: true,
    prefixes: []
};

module.exports.run = async function ({ api, event, args, prefix }) {
    const { threadID, messageID, senderID } = event;
    const keyword = args.join(" ");

    if (!keyword) {
        return api.sendMessage(`Vui lòng nhập từ khóa tìm kiếm.\nDùng: ${prefix}scl [tên bài hát | video]`, threadID, messageID);
    }

    const isAudioOnly = keyword.toLowerCase().includes("mp3") || keyword.toLowerCase().includes("audio");

    if (keyword.toLowerCase().includes("video") || !isAudioOnly) {
        try {
            const link = [];
            const data = (await Youtube.GetListByKeyword(keyword, false, 8)).items;
            if (!data.length) return api.sendMessage("Không tìm thấy kết quả trên YouTube.", threadID, messageID);

            const msg = data.map((v, i) => {
                link.push(v.id);
                const length = v.length?.simpleText || "Không rõ";
                const reactionCount = v.reactionCount?.toLocaleString();
                const reactions = reactionCount ? ` | 👍 ${reactionCount}` : '';
                return `|› ${i + 1}. ${v.title}\n|› 👤 Kênh: ${v.channelTitle}\n|› ⏱️ Thời lượng: ${length}${reactions}\n──────────────────`;
            }).join('\n');

            return api.sendMessage(
                `📝 Tìm thấy ${link.length} kết quả trên YouTube:\n${msg}\n\n📌 Reply số để tải video${isAudioOnly ? " dưới dạng âm thanh (mp3)" : " (mp4 mặc định)"}`,
                threadID,
                (err, info) => global.client.handleReply.push({
                    type: 'youtube',
                    isAudio: isAudioOnly,
                    name: this.config.name,
                    messageID: info.messageID,
                    author: senderID,
                    link
                }),
                messageID
            );
        } catch (e) {
            console.error("YouTube search error:", e);
            return api.sendMessage("❎ Lỗi khi tìm kiếm video trên YouTube.", threadID, messageID);
        }
    } else {
        try {
            const tracks = await searchTracks(keyword);
            if (tracks.length === 0) return api.sendMessage("Không tìm thấy bài hát nào trên SoundCloud.", threadID, messageID);

            let msg = "╭─〔🎧〕──〔SOUNDCLOUD〕──〔🎶〕─╮\n";
            tracks.forEach((track, i) => {
                msg += `│ ${i + 1}. ${track.title}\n│ ⏱ ${track.duration} | 👤 ${track.artist}\n│ 👁 ${track.playCount.toLocaleString()} lượt nghe | ❤ ${track.likeCount.toLocaleString()} thích\n├────────────────────\n`;
            });
            msg += "╰➤ Reply số để tải bài mp3.";

            searchResults[senderID] = { type: 'soundcloud', results: tracks };

            return api.sendMessage(msg, threadID, (err, info) => {
                global.client.handleReply.push({
                    name: this.config.name,
                    messageID: info.messageID,
                    author: senderID,
                    type: "soundcloud"
                });
            }, messageID);
        } catch (error) {
            console.error("SoundCloud error:", error);
            return api.sendMessage("❎ Đã xảy ra lỗi khi tìm kiếm trên SoundCloud.", threadID, messageID);
        }
    }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
    const { threadID, messageID, senderID, body } = event;
    if (handleReply.author !== senderID) return;

    const choice = parseInt(body);
    if (isNaN(choice) || choice <= 0) return api.sendMessage("Lựa chọn không hợp lệ.", threadID, messageID);
    api.unsendMessage(handleReply.messageID);

    if (handleReply.type === 'soundcloud') {
        const track = searchResults[senderID].results[choice - 1];
        if (!track) return api.sendMessage("Không tìm thấy bài hát tương ứng.", threadID, messageID);

        try {
            const result = await downloadTrack(track.url);
            const trackInfo = `🎵 ${result.title}\n🎤 ${result.user.username}\n⏱ ${formatDuration(result.duration)}\n👁 ${result.playback_count.toLocaleString()} lượt nghe\n❤ ${result.likes_count.toLocaleString()} thích\n📥 Đang tải...`;
            const attachment = fs.createReadStream(result.filePath);
            const stats = fs.statSync(result.filePath);

            await api.sendMessage({ body: trackInfo, attachment }, threadID, () => {
                fs.unlinkSync(result.filePath);
                api.sendMessage(`✅ Đã tải xong: ${result.title} (${formatFileSize(stats.size)})`, threadID, messageID);
                delete searchResults[senderID];
            }, messageID);
        } catch (e) {
            console.error(e);
            return api.sendMessage("❎ Lỗi khi tải bài hát.", threadID, messageID);
        }
    } else if (handleReply.type === 'youtube') {
        const id = handleReply.link[choice - 1];
        const isAudio = handleReply.isAudio;
        const ext = isAudio ? 'mp3' : 'mp4';
        const savePath = path.join(__dirname, `/cache/${senderID}.${ext}`);

        try {
            const result = await getdl(`https://www.youtube.com/watch?v=${id}`, isAudio ? "Audio" : "Video", isAudio ? "140" : "18", savePath);
            if (!result) return api.sendMessage("❎ Lỗi tải video.", threadID, messageID);

            const fileSize = fs.statSync(savePath).size;
            if (fileSize > 26214400) {
                fs.unlinkSync(savePath);
                return api.sendMessage(`❎ File quá lớn (trên 25MB) - ${formatFileSize(fileSize)}.`, threadID, messageID);
            }

            const msg = `${isAudio ? "Âm thanh" : "Video"} từ YouTube:\n🎬 ${result.title}\n⏳ Xử lý: ${Math.floor((Date.now() - result.timestart)/1000)}s\n📥 Đang tải... (${formatFileSize(fileSize)})\n⏰ ${moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss | DD/MM/YYYY")}`;

            return api.sendMessage({ body: msg, attachment: fs.createReadStream(savePath) }, threadID, () => {
                fs.unlinkSync(savePath);
            }, messageID);
        } catch (e) {
            console.error(e);
            return api.sendMessage("❎ Lỗi khi tải video.", threadID, messageID);
        }
    }
};
