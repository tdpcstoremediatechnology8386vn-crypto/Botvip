const axios = require('axios');
const moment = require('moment-timezone');
const fs = require('fs');

this.config = {
 name: "upt",
 version: "1.0.0",
 hasPermssion: 0,
 credits: "DC-Nam",
 description: "Hiển thị thời gian hoạt động bot",
 commandCategory: "Tiện ích",
 usePrefix: false,
 usages: "",
 cooldowns: 0
};

// Convert uptime to format: HHH:MM:SS
function convertTime(seconds) {
 const totalHours = Math.floor(seconds / 3600);
 const minutes = Math.floor((seconds % 3600) / 60);
 const sec = Math.floor(seconds % 60);
 const pad = n => String(n).padStart(2, "0");
 return `${totalHours}:${pad(minutes)}:${pad(sec)}`;
}

this.run = async function (o) {
 let send = msg => new Promise(r => o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res || err), o.event.messageID));

 const totalUptime = (global.uptimeOffset || 0) + process.uptime();
 const uptimeStr = convertTime(totalUptime);

 let dependencyCount = -1;
 try {
 const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
 dependencyCount = Object.keys(packageJson.dependencies || {}).length;
 } catch (e) {
 console.error("Không thể đọc package.json:", e);
 }

 let botStatus = "Đang hoạt động";
 let id = o.event.senderID;

 try {
 o.api.shareContact(`⏰ Bây giờ là: ${moment().tz('Asia/Ho_Chi_Minh').format('HH:mm:ss')} | ${moment().tz('Asia/Ho_Chi_Minh').format('DD/MM/YYYY')}
⏱️ Uptime: ${uptimeStr}
📝 Dấu lệnh mặc định: ${global.config.PREFIX}
🗂️ Số lượng package: ${dependencyCount >= 0 ? dependencyCount : "Không xác định"}
🔣 Tình trạng bot: ${botStatus}`, id, o.event.threadID);
 } catch (error) {
 console.error("Lỗi khi chia sẻ liên hệ:", error);
 send({
 body: "Đã có lỗi xảy ra khi chia sẻ thời gian hoạt động."
 });
 }
};