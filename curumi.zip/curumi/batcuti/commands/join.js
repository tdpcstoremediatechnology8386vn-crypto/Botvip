const fs = require('fs');
const path = __dirname + '/data/dataEvent.json';

module.exports.config = {
  name: "noti",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "Gộp bởi Bat",
  description: "Bật/tắt thông báo tham gia/rời nhóm",
  commandCategory: "Qtv",
  usages: "[join/leave]",
  cooldowns: 2
};

module.exports.languages = {
  "vi": {
    "on": "✅ Bật",
    "off": "✅ Tắt",
    "join": "gửi tin nhắn chào mừng khi có thành viên mới tham gia nhóm chat",
    "leave": "gửi tin nhắn thông báo khi có thành viên rời nhóm chat",
    "invalid": "Vui lòng sử dụng: noti join/leave"
  },
  "en": {
    "on": "✅ On",
    "off": "✅ Off",
    "join": "send a welcome message when a new member joins",
    "leave": "send a notification when a member leaves",
    "invalid": "Please use: noti join/leave"
  }
};

exports.onLoad = () => {
  if (!fs.existsSync(path)) fs.writeFileSync(path, '{}');
};

module.exports.run = async function ({ api, event, args, getText }) {
  const { threadID, messageID } = event;
  const type = args[0]?.toLowerCase();

  if (!["join", "leave"].includes(type))
    return api.sendMessage(getText("invalid"), threadID, messageID);

  let data = JSON.parse(fs.readFileSync(path));
  if (!data[type]) data[type] = [];

  let entry = data[type].find(i => i.threadID == threadID);

  if (entry) {
    entry.status = !entry.status;
  } else {
    entry = { threadID, status: true };
    data[type].push(entry);
  }

  fs.writeFileSync(path, JSON.stringify(data, null, 4), 'utf8');

  return api.sendMessage(
    `${entry.status ? getText("on") : getText("off")} ${getText(type)}`,
    threadID,
    messageID
  );
};