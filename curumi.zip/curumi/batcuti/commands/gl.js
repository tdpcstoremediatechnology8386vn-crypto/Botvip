const axios = require("axios");
const fs = require("fs");

class Command {
  constructor(config) {
    this.config = config;
    global.vdtrai = [];
  }

  async onLoad(o) {
    const urls = [
        "https://files.catbox.moe/634186.mp4",
        "https://files.catbox.moe/60umiq.mp4",
        "https://files.catbox.moe/sxfw8w.mp4",
        "https://files.catbox.moe/5k4tsg.mp4",
        "https://files.catbox.moe/f8lhkg.mp4",
        "https://files.catbox.moe/goe5c1.mp4",
        "https://files.catbox.moe/dfhfli.mp4",
        "https://files.catbox.moe/h223r4.mp4",
        "https://files.catbox.moe/80erb3.mp4",
        "https://files.catbox.moe/4tdn1q.mp4",
        "https://files.catbox.moe/fov5e2.mp4",
        "https://files.catbox.moe/69vidv.mp4",
        "https://files.catbox.moe/fml0ox.mp4",
        "https://files.catbox.moe/5x8zjg.mp4",
        "https://files.catbox.moe/1l5a01.mp4",
        "https://files.catbox.moe/jlycau.mp4",
        "https://files.catbox.moe/w9bbae.mp4",
        "https://files.catbox.moe/k02a19.mp4",
        "https://files.catbox.moe/gnrjze.mp4",
        "https://files.catbox.moe/3ovofn.mp4",
        "https://files.catbox.moe/x2qgob.mp4",
        "https://files.catbox.moe/r2mpha.mp4",
        "https://files.catbox.moe/62yv20.mp4",
        "https://files.catbox.moe/6c0fj5.mp4",
        "https://files.catbox.moe/yyfhld.mp4",
        "https://files.catbox.moe/pwvhbp.mp4",
        "https://files.catbox.moe/4kupsu.mp4",
        "https://files.catbox.moe/q6hvkc.mp4",
        "https://files.catbox.moe/w22b09.mp4",
        "https://files.catbox.moe/1gxze4.mp4",
        "https://files.catbox.moe/kq8tod.mp4",
        "https://files.catbox.moe/xu0q37.mp4",
        "https://files.catbox.moe/6ntobp.mp4",
        "https://files.catbox.moe/ch5ujb.mp4",
        "https://files.catbox.moe/43l616.mp4",
        "https://files.catbox.moe/zr0kpq.mp4",
        "https://files.catbox.moe/6w6tv3.mp4",
        "https://files.catbox.moe/bmnrom.mp4",
        "https://files.catbox.moe/xafxdx.mp4",
        "https://files.catbox.moe/mwattv.mp4",
        "https://files.catbox.moe/p70h99.mp4",
        "https://files.catbox.moe/6m3gmc.mp4",
        "https://files.catbox.moe/7ejzih.mp4",
        "https://files.catbox.moe/0gnvns.mp4",
        "https://files.catbox.moe/lkiqy1.mp4",
        "https://files.catbox.moe/ee1tq0.mp4",
        "https://files.catbox.moe/c1nxqq.mp4",
        "https://files.catbox.moe/oyx7sl.mp4",
        "https://files.catbox.moe/dwmzh3.mp4",
        "https://files.catbox.moe/8z2kg7.mp4",
        "https://files.catbox.moe/q6oeyk.mp4",
        "https://files.catbox.moe/bjbv4s.mp4",
        "https://files.catbox.moe/w4erxz.mp4",
        "https://files.catbox.moe/h0y9vh.mp4",
        "https://files.catbox.moe/4tcp4y.mp4",
        "https://files.catbox.moe/my1eys.mp4",
        "https://files.catbox.moe/kgbofn.mp4",
        "https://files.catbox.moe/bybf4p.mp4",
        "https://files.catbox.moe/gkgn9g.mp4",
        "https://files.catbox.moe/13sdme.mp4",
        "https://files.catbox.moe/p2i1uc.mp4",
        "https://files.catbox.moe/tp2wt0.mp4",
        "https://files.catbox.moe/glmlir.mp4",
        "https://files.catbox.moe/wr9el1.mp4",
        "https://files.catbox.moe/v3kyln.mp4",
        "https://files.catbox.moe/shq1sl.mp4",
        "https://files.catbox.moe/rhi8dy.mp4",
        "https://files.catbox.moe/w2ayi1.mp4",
        "https://files.catbox.moe/uco0wh.mp4",
        "https://files.catbox.moe/yc1qws.mp4",
        "https://files.catbox.moe/xcly9o.mp4",
        "https://files.catbox.moe/jks71a.mp4",
        "https://files.catbox.moe/0ttcik.mp4",
        "https://files.catbox.moe/lqildu.mp4",
        "https://files.catbox.moe/oj7b71.mp4",
        "https://files.catbox.moe/4cin9h.mp4",
        "https://files.catbox.moe/5kv2vc.mp4",
        "https://files.catbox.moe/x1pbrs.mp4",
        "https://files.catbox.moe/l8d5qr.mp4",
        "https://files.catbox.moe/el2piv.mp4",
        "https://files.catbox.moe/hm9zzs.mp4",
        "https://files.catbox.moe/8g25sm.mp4",
        "https://files.catbox.moe/atwws2.mp4",
        "https://files.catbox.moe/x1idwi.mp4",
        "https://files.catbox.moe/r0zoum.mp4",
        "https://files.catbox.moe/7nr8ma.mp4",
        "https://files.catbox.moe/ctqrud.mp4",
        "https://files.catbox.moe/dic9be.mp4",
        "https://files.catbox.moe/rsd1cs.mp4",
        "https://files.catbox.moe/vfzzrp.mp4",
        "https://files.catbox.moe/m4nd6q.mp4",
        "https://files.catbox.moe/497xx8.mp4",
        "https://files.catbox.moe/5ltlm3.mp4",
        "https://files.catbox.moe/g3kms7.mp4",
        "https://files.catbox.moe/ks8qz6.mp4",
        "https://files.catbox.moe/6yahgs.mp4",
        "https://files.catbox.moe/lvhpzj.mp4",
        "https://files.catbox.moe/f9nbux.mp4",
        "https://files.catbox.moe/erk7nn.mp4",
        "https://files.catbox.moe/wmwk26.mp4",
        "https://files.catbox.moe/krzw0j.mp4",
        "https://files.catbox.moe/vkkuai.mp4",
        "https://files.catbox.moe/f3n1zj.mp4",
        "https://files.catbox.moe/ljpd3m.mp4",
        "https://files.catbox.moe/6f1glx.mp4",
        "https://files.catbox.moe/z1nf2j.mp4",
        "https://files.catbox.moe/j93wzu.mp4",
        "https://files.catbox.moe/muo84n.mp4",
        "https://files.catbox.moe/yvzexr.mp4",
        "https://files.catbox.moe/2ywtlh.mp4",
        "https://files.catbox.moe/hos7ox.mp4",
        "https://files.catbox.moe/k1zdrd.mp4",
        "https://files.catbox.moe/nxfahk.mp4",
        "https://files.catbox.moe/uwgkkh.mp4",
        "https://files.catbox.moe/1wv65f.mp4",
        "https://files.catbox.moe/glddsj.mp4",
        "https://files.catbox.moe/q695cn.mp4",
        "https://files.catbox.moe/9mdbb7.mp4",
        "https://files.catbox.moe/eds42u.mp4",
        "https://files.catbox.moe/vdnike.mp4",
        "https://files.catbox.moe/83fcd1.mp4",
        "https://files.catbox.moe/bydokk.mp4",
        "https://files.catbox.moe/k4gliz.mp4",
        "https://files.catbox.moe/2gjmzu.mp4",
        "https://files.catbox.moe/jkfl4g.mp4",
        "https://files.catbox.moe/uohm2l.mp4",
        "https://files.catbox.moe/4oicbi.mp4",
        "https://files.catbox.moe/ogx1i6.mp4",
        "https://files.catbox.moe/bijbsd.mp4",
        "https://files.catbox.moe/fid53g.mp4",
        "https://files.catbox.moe/qnb2m7.mp4",
        "https://files.catbox.moe/yh60u1.mp4",
        "https://files.catbox.moe/mmcud0.mp4",
        "https://files.catbox.moe/66dtvu.mp4",
        "https://files.catbox.moe/fz57b2.mp4",
        "https://files.catbox.moe/l8d5qr.mp4",
  "https://files.catbox.moe/el2piv.mp4",
  "https://files.catbox.moe/hm9zzs.mp4",
  "https://files.catbox.moe/8g25sm.mp4",
  "https://files.catbox.moe/atwws2.mp4",
  "https://files.catbox.moe/x1idwi.mp4",
  "https://files.catbox.moe/r0zoum.mp4",
  "https://files.catbox.moe/7nr8ma.mp4",
  "https://files.catbox.moe/ctqrud.mp4",
  "https://files.catbox.moe/dic9be.mp4",
  "https://files.catbox.moe/rsd1cs.mp4",
  "https://files.catbox.moe/vfzzrp.mp4",
  "https://files.catbox.moe/m4nd6q.mp4",
  "https://files.catbox.moe/497xx8.mp4",
  "https://files.catbox.moe/5ltlm3.mp4",
  "https://files.catbox.moe/g3kms7.mp4",
  "https://files.catbox.moe/ks8qz6.mp4",
  "https://files.catbox.moe/6yahgs.mp4",
  "https://files.catbox.moe/lvhpzj.mp4",
  "https://files.catbox.moe/f9nbux.mp4",
  "https://files.catbox.moe/erk7nn.mp4",
  "https://files.catbox.moe/wmwk26.mp4",
  "https://files.catbox.moe/krzw0j.mp4",
  "https://files.catbox.moe/vkkuai.mp4",
  "https://files.catbox.moe/f3n1zj.mp4",
  "https://files.catbox.moe/ljpd3m.mp4",
  "https://files.catbox.moe/6f1glx.mp4",
  "https://files.catbox.moe/z1nf2j.mp4",
  "https://files.catbox.moe/j93wzu.mp4",
  "https://files.catbox.moe/muo84n.mp4",
  "https://files.catbox.moe/yvzexr.mp4",
  "https://files.catbox.moe/2ywtlh.mp4",
  "https://files.catbox.moe/hos7ox.mp4",
  "https://files.catbox.moe/k1zdrd.mp4",
  "https://files.catbox.moe/nxfahk.mp4",
  "https://files.catbox.moe/uwgkkh.mp4",
  "https://files.catbox.moe/1wv65f.mp4",
  "https://files.catbox.moe/glddsj.mp4",
  "https://files.catbox.moe/q695cn.mp4",
  "https://files.catbox.moe/9mdbb7.mp4",
  "https://files.catbox.moe/eds42u.mp4",
  "https://files.catbox.moe/vdnike.mp4",
  "https://files.catbox.moe/83fcd1.mp4",
  "https://files.catbox.moe/bydokk.mp4",
  "https://files.catbox.moe/k4gliz.mp4",
  "https://files.catbox.moe/2gjmzu.mp4",
  "https://files.catbox.moe/jkfl4g.mp4",
  "https://files.catbox.moe/uohm2l.mp4",
  "https://files.catbox.moe/4oicbi.mp4",
  "https://files.catbox.moe/ogx1i6.mp4",
  "https://files.catbox.moe/bijbsd.mp4",
  "https://files.catbox.moe/fid53g.mp4",
  "https://files.catbox.moe/qnb2m7.mp4",
  "https://files.catbox.moe/yh60u1.mp4",
  "https://files.catbox.moe/mmcud0.mp4",
  "https://files.catbox.moe/66dtvu.mp4",
  "https://files.catbox.moe/fz57b2.mp4",
  "https://files.catbox.moe/gluejk.mp4",
  "https://files.catbox.moe/h32dmd.mp4",
  "https://files.catbox.moe/bvikk0.mp4",
  "https://files.catbox.moe/69w1r6.mp4",
  "https://files.catbox.moe/yyo0gw.mp4",
  "https://files.catbox.moe/iq9i6j.mp4",
  "https://files.catbox.moe/c2dwpv.mp4",
  "https://files.catbox.moe/23ubu0.mp4",
  "https://files.catbox.moe/euiaii.mp4",
  "https://files.catbox.moe/dne85o.mp4",
  "https://files.catbox.moe/p1y2zj.mp4",
  "https://files.catbox.moe/c6ik20.mp4",
  "https://files.catbox.moe/4xn4gy.mp4",
"https://files.catbox.moe/2z2arw.mp4",
"https://files.catbox.moe/wa9t4n.mp4",
"https://files.catbox.moe/clklz4.mp4",
"https://files.catbox.moe/o99lnw.mp4",
"https://files.catbox.moe/2w3zn5.mp4",
        "https://files.catbox.moe/crso4f.mp4",
        "https://files.catbox.moe/m7dnh1.mp4",
        "https://files.catbox.moe/mo4o9b.mp4",
        "https://files.catbox.moe/d8bnsz.mp4",
        "https://files.catbox.moe/n7ji0x.mp4",
        "https://files.catbox.moe/6r7tnz.mp4",
        "https://files.catbox.moe/g2yx47.mp4",
        "https://files.catbox.moe/ol7tyz.mp4",
        "https://files.catbox.moe/5lkn1t.mp4",
        "https://files.catbox.moe/klb3p4.mp4",
        "https://files.catbox.moe/5rq9gx.mp4",
        "https://files.catbox.moe/ogxo3a.mp4",
        "https://files.catbox.moe/nzsa77.mp4",
        "https://files.catbox.moe/ptzhhc.mp4",
        "https://files.catbox.moe/gomqsc.mp4",
        "https://files.catbox.moe/tod9ye.mp4",
        "https://files.catbox.moe/gl0v68.mp4",
        "https://files.catbox.moe/kyrrzc.mp4",
        "https://files.catbox.moe/laap3n.mp4",
        "https://files.catbox.moe/emtzr8.mp4",
        "https://files.catbox.moe/0eovgq.mp4",
        "https://files.catbox.moe/sbb5nb.mp4",
        "https://files.catbox.moe/qtgrgx.mp4",
        "https://files.catbox.moe/5zuaif.mp4",
        "https://files.catbox.moe/87fgx3.mp4",
        "https://files.catbox.moe/y8v4ii.mp4",
        "https://files.catbox.moe/h45kvd.mp4",
        "https://files.catbox.moe/t9lkwr.mp4",
        "https://files.catbox.moe/wh7lww.mp4",
        "https://files.catbox.moe/t1t4hb.mp4",
        "https://files.catbox.moe/64jtg5.mp4",
        "https://files.catbox.moe/vp892o.mp4",
        "https://files.catbox.moe/u9utcw.mp4",
        "https://files.catbox.moe/zutrq5.mp4",
        "https://files.catbox.moe/c468eb.mp4"
,
  "https://files.catbox.moe/6vc0zc.mp4",
  "https://files.catbox.moe/05gvyj.mp4",
  "https://files.catbox.moe/r23at0.mp4",
  "https://files.catbox.moe/g3k6iu.mp4",
  "https://files.catbox.moe/9y6qw1.mp4",
  "https://files.catbox.moe/suzls2.mp4",
  "https://files.catbox.moe/uh5wsy.mp4",
  "https://files.catbox.moe/hfdutt.mp4",
  "https://files.catbox.moe/x16yn9.mp4",
  "https://files.catbox.moe/e7b2eq.mp4",
  "https://files.catbox.moe/r1cjxa.mp4",
  "https://files.catbox.moe/ntkmfg.mp4",
  "https://files.catbox.moe/2n4xnv.mp4",
  "https://files.catbox.moe/fo5219.mp4",
  "https://files.catbox.moe/uiahmk.mp4",
  "https://files.catbox.moe/ipb2kx.mp4",
  "https://files.catbox.moe/80vior.mp4",
  "https://files.catbox.moe/qo6fa1.mp4",
  "https://files.catbox.moe/pybkuv.mp4",
  "https://files.catbox.moe/gj1q39.mp4",
  "https://files.catbox.moe/2irvkj.mp4",
  "https://files.catbox.moe/oa46hq.mp4",
  "https://files.catbox.moe/fqbzes.mp4",
  "https://files.catbox.moe/9n3ckj.mp4",
  "https://files.catbox.moe/imzhhr.mp4",
  "https://files.catbox.moe/ncjcc4.mp4"
]

    let status = false;

    if (!global.client.xôx)
      global.client.xôx = setInterval(async () => {
        if (status === true || global.vdtrai.length > 10) return;
        status = true;

        Promise.all(
          [...Array(5)].map(() =>
            upload(urls[Math.floor(Math.random() * urls.length)])
          )
        ).then((res) => {
          console.log(res, ...res);
          global.vdtrai.push(...res);
          status = false;
        });
      }, 1000 * 5);

    async function streamURL(url, type) {
      return axios
        .get(url, {
          responseType: "arraybuffer",
        })
        .then((res) => {
          const path = __dirname + `/cache/${Date.now()}.${type}`;
          fs.writeFileSync(path, res.data);
          setTimeout((p) => fs.unlinkSync(p), 1000 * 60, path);
          return fs.createReadStream(path);
        });
    }

    async function upload(url) {
      return o.api
        .httpPostFormData("https://upload.facebook.com/ajax/mercury/upload.php", {
          upload_1024: await streamURL(url, "mp4"),
        })
        .then((res) =>
          Object.entries(JSON.parse(res.replace("for (;;);", "")).payload?.metadata?.[0] || {})[0]
        );
    }
  }

  async run(o) {
    const response = await axios.get("https://raw.githubusercontent.com/Sang070801/api/main/thinh1.json");
    const data = response.data;
    const thinhArray = Object.values(data.data);
    const randomThinh = thinhArray[Math.floor(Math.random() * thinhArray.length)];

    const send = (msg) =>
      new Promise((r) =>
        o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res || err), o.event.messageID)
      );

    const t = process.uptime();
    const h = Math.floor(t / 3600);
    const p = Math.floor((t % 3600) / 60);
    const s = Math.floor(t % 60);

    send({
      body: `Thời gian hoạt động\n            ${h}:${p}:${s}`,
      attachment: global.vdtrai.splice(0, 1),
    });
  }
}

module.exports = new Command({
  name: "gl",
  version: "0.0.1",
  hasPermssion: 2,
  credits: "DC-Nam ( Bat )",
  description: "",
  commandCategory: "Tiện ích",
  usages: "[]",
  cooldowns: 0,
});
