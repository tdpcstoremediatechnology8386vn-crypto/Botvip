const axios = require("axios");

module.exports.config = {
  name: "vdtrai",
  version: "2.0.5",
  hasPermssion: 0,
  credits: "Tpk | mod by Bat",
  description: "Gửi video trai",
  commandCategory: "Tiện ích",
  usages: "",
  cooldowns: 0
};

module.exports.run = async ({ api, event }) => {
  const videoUrls = [
  "https://files.catbox.moe/634186.mp4",
  "https://files.catbox.moe/60umiq.mp4",
  "https://files.catbox.moe/sxfw8w.mp4",
  "https://files.catbox.moe/5k4tsg.mp4",
  "https://files.catbox.moe/f8lhkg.mp4",
  "https://files.catbox.moe/goe5c1.mp4",
  "https://files.catbox.moe/dfhfli.mp4",
  "https://files.catbox.moe/h223r4.mp4",
  "https://files.catbox.moe/80erb3.mp4",
  "https://files.catbox.moe/4tdn1q.mp4",
  "https://files.catbox.moe/fov5e2.mp4",
  "https://files.catbox.moe/69vidv.mp4",
  "https://files.catbox.moe/fml0ox.mp4",
  "https://files.catbox.moe/5x8zjg.mp4",
  "https://files.catbox.moe/1l5a01.mp4",
  "https://files.catbox.moe/jlycau.mp4",
  "https://files.catbox.moe/w9bbae.mp4",
  "https://files.catbox.moe/k02a19.mp4",
  "https://files.catbox.moe/gnrjze.mp4",
  "https://files.catbox.moe/3ovofn.mp4",
  "https://files.catbox.moe/x2qgob.mp4",
  "https://files.catbox.moe/r2mpha.mp4",
  "https://files.catbox.moe/62yv20.mp4",
  "https://files.catbox.moe/6c0fj5.mp4",
  "https://files.catbox.moe/yyfhld.mp4",
  "https://files.catbox.moe/pwvhbp.mp4",
  "https://files.catbox.moe/4kupsu.mp4",
  "https://files.catbox.moe/q6hvkc.mp4",
  "https://files.catbox.moe/w22b09.mp4",
  "https://files.catbox.moe/1gxze4.mp4",
  "https://files.catbox.moe/kq8tod.mp4",
  "https://files.catbox.moe/xu0q37.mp4",
  "https://files.catbox.moe/6ntobp.mp4",
  "https://files.catbox.moe/ch5ujb.mp4",
  "https://files.catbox.moe/43l616.mp4",
  "https://files.catbox.moe/zr0kpq.mp4",
  "https://files.catbox.moe/6w6tv3.mp4",
  "https://files.catbox.moe/bmnrom.mp4",
  "https://files.catbox.moe/xafxdx.mp4",
  "https://files.catbox.moe/mwattv.mp4",
  "https://files.catbox.moe/p70h99.mp4",
  "https://files.catbox.moe/6m3gmc.mp4",
  "https://files.catbox.moe/7ejzih.mp4",
  "https://files.catbox.moe/0gnvns.mp4",
  "https://files.catbox.moe/lkiqy1.mp4",
  "https://files.catbox.moe/ee1tq0.mp4",
  "https://files.catbox.moe/c1nxqq.mp4",
  "https://files.catbox.moe/oyx7sl.mp4",
  "https://files.catbox.moe/dwmzh3.mp4",
  "https://files.catbox.moe/8z2kg7.mp4",
  "https://files.catbox.moe/q6oeyk.mp4",
  "https://files.catbox.moe/bjbv4s.mp4",
  "https://files.catbox.moe/w4erxz.mp4"
];

  if (videoUrls.length === 0) {
    return api.sendMessage("Chưa có video nào để gửi.", event.threadID, event.messageID);
  }

  const url = videoUrls[Math.floor(Math.random() * videoUrls.length)];
  const stream = (await axios.get(url, { responseType: "stream" })).data;

  api.sendMessage({
    body: " ",
    attachment: stream
  }, event.threadID, event.messageID);
};
