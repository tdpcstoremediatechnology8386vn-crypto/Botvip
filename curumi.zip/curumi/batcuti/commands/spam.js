module.exports.config = {
  name: "sp",
  version: "2.0.0",
  hasPermssion: 3,
  credits: "anhthu",
  description: "Spam đến 1 box thông qua UID + Xem danh sách nhóm bot đang ở",
  commandCategory: "Admin",
  usages: "[uid box] [số lần] [nội dung] | list",
  cooldowns: 2
};

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports.run = async function ({ api, event, args, permssion }) {
  const { threadID, messageID } = event;

  if (permssion < 3)
    return api.sendMessage("Bạn không đủ quyền sử dụng lệnh này.", threadID, messageID);

  // Nếu là lệnh xem danh sách box
  if (args[0] === "list") {
    try {
      const allThreads = await api.getThreadList(100, null, ["INBOX"]);
      const groupThreads = allThreads.filter(thread => thread.isGroup && thread.name);

      if (groupThreads.length === 0)
        return api.sendMessage("Bot không tham gia nhóm nào cả.", threadID, messageID);

      let msg = "📋 Danh sách nhóm bot đang ở:\n\n";
      let count = 0;

      for (const thread of groupThreads) {
        count++;
        msg += `${count}. ${thread.name}\nUID: ${thread.threadID}\n\n`;
      }

      msg += `Tổng: ${count} nhóm.`;
      return api.sendMessage(msg, threadID, messageID);
    } catch (err) {
      console.error(err);
      return api.sendMessage("❌ Lỗi khi lấy danh sách nhóm.", threadID, messageID);
    }
  }

  // Nếu là spam
  if (args.length < 3)
    return api.sendMessage("Sai cú pháp!\nDùng: spamuid [uid box] [số lần] [nội dung] hoặc spamuid list", threadID, messageID);

  const targetUID = args[0];
  const times = parseInt(args[1]);
  const content = args.slice(2).join(" ");

  if (isNaN(times) || times <= 0 || times > 100)
    return api.sendMessage("Số lần spam phải là số hợp lệ (1-100).", threadID, messageID);

  api.sendMessage(`⏳ Bắt đầu spam ${times} lần đến box ${targetUID}`, threadID, messageID);

  for (let i = 0; i < times; i++) {
    try {
      await api.sendMessage(content, targetUID);
      await delay(4); // 1s mỗi lần để tránh chặn
    } catch (err) {
      console.error(err);
      return api.sendMessage("❌ Lỗi khi gửi tin nhắn!", threadID, messageID);
    }
  }

  return api.sendMessage(`✅ Đã spam xong ${times} lần đến box ${targetUID}`, threadID);
};