module.exports = {
  config: {
    name: "kick",
    version: "1.0",
    hasPermission: 1, // chỉ admin bot
    credits: "GPT",
    description: "Kick người khỏi nhóm",
    commandCategory: "group",
    usages: "[reply | @tag | uid]",
    cooldowns: 3,
  },

  run: async ({ api, event, args }) => {
    const { threadID, messageID, senderID, messageReply, mentions } = event;

    // Lấy danh sách admin nhóm
    const threadInfo = await api.getThreadInfo(threadID);
    const adminIDs = threadInfo.adminIDs.map(e => e.id);

    // Kiểm tra quyền người dùng
    if (!adminIDs.includes(senderID))
      return api.sendMessage("⚠️ Bạn cần là quản trị viên nhóm để sử dụng lệnh này.", threadID, messageID);

    // Không thể kick chính bot
    const botID = api.getCurrentUserID();

    // Tạo danh sách UID cần kick
    let targetIDs = [];

    if (messageReply) {
      targetIDs.push(messageReply.senderID);
    } else if (Object.keys(mentions).length > 0) {
      targetIDs = Object.keys(mentions);
    } else if (args[0]) {
      targetIDs = args.filter(uid => /^\d+$/.test(uid));
    } else {
      return api.sendMessage("⚠️ Vui lòng reply hoặc @tag người cần kick.", threadID, messageID);
    }

    // Kick từng UID
    const kicked = [], failed = [];

    for (const uid of targetIDs) {
      if (uid === botID) {
        failed.push("Bot");
        continue;
      }

      try {
        await api.removeUserFromGroup(uid, threadID);
        kicked.push(uid);
      } catch (e) {
        failed.push(uid);
      }
    }

    let msg = "";
    if (kicked.length) msg += `✅ Đã kick: ${kicked.join(", ")}\n`;
    if (failed.length) msg += `❌ Kick thất bại: ${failed.join(", ")}`;

    return api.sendMessage(msg.trim(), threadID, messageID);
  }
};