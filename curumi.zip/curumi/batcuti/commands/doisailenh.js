const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");

const modePath = path.join(__dirname, "../../batcuti/commands/data/gai_mode.json");

module.exports.config = {
  name: "doisailenh",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Bat",
  description: "Bật/tắt hiển thị thính khi gửi video gái",
  commandCategory: "Tiện ích",
  usages: "",
  cooldowns: 3
};

module.exports.run = async ({ api, event }) => {
  const { threadID, messageID } = event;

  let modeData = {};
  try {
    modeData = JSON.parse(await fsp.readFile(modePath, "utf-8"));
  } catch {
    modeData = {};
  }

  const current = modeData[threadID] || "full";
  const next = current === "full" ? "phụ" : "full";
  modeData[threadID] = next;

  await fsp.writeFile(modePath, JSON.stringify(modeData, null, 2));

  const msg = next === "full"
    ? "✅ Đã bật chế độ gốc"
    : "🕒 Đã bật chế độ phụ";

  api.sendMessage(msg, threadID, messageID);
};