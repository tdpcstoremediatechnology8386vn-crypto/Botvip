const fs = require("fs");

module.exports.config = {
  name: "warn",
  version: "1.0.0",
  hasPermssion: 1, // chỉ Admin hoặc QTV mới dùng được
  credits: "Bat",
  description: "Cảnh báo thành viên, quá 3 lần sẽ bị kick",
  commandCategory: "Quản trị nhóm",
  usages: "[tag]",
  cooldowns: 5
};

let warnPath = __dirname + "/cache/warnData.json";
if (!fs.existsSync(warnPath)) fs.writeFileSync(warnPath, "{}");

module.exports.run = async ({ api, event }) => {
  const { threadID, messageID, senderID, mentions, messageReply } = event;
  const warnData = JSON.parse(fs.readFileSync(warnPath, "utf-8"));

  let uid;
  if (Object.keys(mentions).length > 0) {
    uid = Object.keys(mentions)[0];
  } else if (messageReply) {
    uid = messageReply.senderID;
  } else {
    return api.sendMessage("⚠️ Bạn cần tag người cần cảnh báo hoặc reply tin nhắn của họ.", threadID, messageID);
  }

  // Tạo mảng nếu chưa có nhóm
  if (!warnData[threadID]) warnData[threadID] = {};
  if (!warnData[threadID][uid]) warnData[threadID][uid] = 0;

  warnData[threadID][uid] += 1;
  const warns = warnData[threadID][uid];

  fs.writeFileSync(warnPath, JSON.stringify(warnData, null, 2));

  if (warns >= 3) {
    api.sendMessage(`🚫 Người dùng bị cảnh báo 3 lần và sẽ bị kick.`, threadID, () => {
      api.removeUserFromGroup(uid, threadID);
      delete warnData[threadID][uid];
      fs.writeFileSync(warnPath, JSON.stringify(warnData, null, 2));
    });
  } else {
    api.sendMessage(`⚠️ Đã cảnh báo ${warns}/3.`, threadID, messageID);
  }
};