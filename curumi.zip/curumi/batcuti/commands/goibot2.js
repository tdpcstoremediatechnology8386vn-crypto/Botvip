const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  GoogleGenerativeAI,
  HarmCategory,
  HarmBlockThreshold,
} = require("@google/generative-ai");
const cheerio = require('cheerio');
const {
  createReadStream,
  unlinkSync
} = require("fs-extra");
const moment = require("moment-timezone"); // Thêm moment-timezone

const API_KEY = "AIzaSyBGNj5a_HywDCjzqhjZBPKRjJkHbaQRZ5s";
const genAI = new GoogleGenerativeAI(API_KEY);
const dataFile = path.join(__dirname, "data", "goibot2.json");
const MODEL_NAME = "gemini-1.5-flash-latest";
const generationConfig = {
  temperature: 1,
  topK: 0,
  topP: 0.95,
  maxOutputTokens: 88192,
};
if (!fs.existsSync(dataFile)) {
  fs.writeFileSync(dataFile, JSON.stringify({}));
}

// Translations for weather conditions (from Rina)
const weatherTranslations = {
  'sunny': 'Trời Nắng',
  'mostly sunny': 'Nhiều Nắng',
  'partly sunny': 'Nắng Vài Nơi',
  'rain showers': 'Mưa Rào',
  't-storms': 'Có Bão',
  'light rain': 'Mưa Nhỏ',
  'mostly cloudy': 'Trời Nhiều Mây',
  'rain': 'Trời Mưa',
  'heavy t-storms': 'Bão Lớn',
  'partly cloudy': 'Mây Rải Rác',
  'mostly clear': 'Trời Trong Xanh',
  'cloudy': 'Trời Nhiều Mây',
  'clear': 'Trời Trong Xanh, Không Mây'
};

function translateWeather(weather) {
  const normalized = weather.toLowerCase();
  return weatherTranslations[normalized] || weather;
}

// Function to get weather data (from Rina)
async function getWeather(location) {
  try {
    const res = await axios.get(`https://api.popcat.xyz/weather?q=${encodeURIComponent(location)}`);
    const data = res.data[0];

    if (!data || !data.current) return null;

    return {
      name: data.location.name,
      temp: data.current.temperature,
      feels: data.current.feelslike,
      sky: translateWeather(data.current.skytext),
      humidity: data.current.humidity,
      wind: data.current.winddisplay
    };
  } catch (err) {
    console.error("Lỗi khi gọi API thời tiết:", err.message);
    return null;
  }
}

// Function to generate image from prompt (from Rina)
async function generateImageFromPrompt(prompt) {
  try {
    const params = {
      width: 512,
      height: 512,
      seed: Math.floor(Math.random() * 10000),
      model: "flux",
      nologo: true,
      enhance: false
    };
    const queryParams = new URLSearchParams(params);
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?${queryParams.toString()}`;
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    if (response.status !== 200) throw new Error(`HTTP error! status: ${response.status}`);
    return `data:image/png;base64,${Buffer.from(response.data, 'binary').toString('base64')}`;
  } catch (error) {
    console.error("Lỗi tạo ảnh:", error.message);
    return `Mẫn Nhi bó tay! Không vẽ được ảnh chi hết 😢\nLỗi: ${error.message}`;
  }
}

// Function to send image (from Rina)
async function sendImage(prompt, api, threadID, messageID) {
  const imageData = await generateImageFromPrompt(prompt);
  if (imageData.startsWith("data:image")) {
    const imgPath = path.join(__dirname, "cache", `mannhi_img_${Date.now()}.png`);
    fs.writeFileSync(imgPath, Buffer.from(imageData.split(",")[1], 'base64'));
    return api.sendMessage({
      body: "🤩 Ảnh nì Mẫn Nhi mới vẽ xong đó~",
      attachment: fs.createReadStream(imgPath)
    }, threadID, () => fs.unlinkSync(imgPath), messageID);
  } else {
    return api.sendMessage(imageData, threadID, messageID);
  }
}

module.exports.config = {
  name: "bot2",
  version: "2.1.0",
  hasPermssion: 0,
  credits: "DC-Nam, Duy Toàn, Hùng, Duy Anh | mod thêm by bat",
  description: "Trò chuyện cùng Gemini chat cực thông minh (có thể ngu) tích hợp tìm nhạc và các tính năng của Rina",
  commandCategory: "AI",
  usages: "bot hoặc [on/off/nội dung]",
  cd: 2,
};

module.exports.run = async function({
  api,
  event,
  args
}) {
  const threadID = event.threadID;
  const senderID = event.senderID;
  const messageID = event.messageID;

  // Initial message for usage
  if (!args[0]) {
    api.sendMessage(`🌸 Mẫn Nhi đây! Mình có thể:\n- Gọi "nhi" để trò chuyện :3\n- Tìm nhạc: "nhi, tìm bài ACIDO"\n- Xem thời tiết: "nhi xem thời tiết (tên địa điểm)"\n- Tạo ảnh: "nhi tạo ảnh (mô tả)"\n- Lấy thông tin nhóm: "nhi lấy thông tin"\n💡 Hỏi mình bất cứ gì nha!`, threadID, messageID);
    // await logUsage?.("Xem gợi ý", threadID, senderID); // Uncomment if logUsage is defined
    return;
  }

  const isTurningOn = args[0] === "on";
  const isTurningOff = args[0] === "off";

  if (isTurningOn || isTurningOff) {
    try {
      const data = JSON.parse(fs.readFileSync(dataFile, "utf-8"));
      data[threadID] = isTurningOn;
      fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));

      api.sendMessage(
        isTurningOn ?
        "✅ Đã bật bot ở nhóm này." :
        "☑ Đã tắt bot ở nhóm này.",
        threadID,
        messageID
      );
    } catch (error) {
      console.error("Lỗi khi thay đổi trạng thái:", error);
      api.sendMessage("⚠️ Có lỗi xảy ra khi thay đổi trạng thái!", threadID, messageID);
    }
    return;
  }
};

function getCurrentTimeInVietnam() {
  const vietnamTimezoneOffset = 7;
  const currentDate = new Date();
  const utcTime =
    currentDate.getTime() + currentDate.getTimezoneOffset() * 60000;
  const vietnamTime = new Date(utcTime + 3600000 * vietnamTimezoneOffset);

  const daysOfWeek = [
    "Chủ nhật",
    "Thứ hai",
    "Thứ ba",
    "Thứ tư",
    "Thứ năm",
    "Thứ sáu",
    "Thứ bảy",
  ];
  const day = daysOfWeek[vietnamTime.getDay()];
  const dateString = `${day} - ${vietnamTime.toLocaleDateString("vi-VN")}`;
  const timeString = vietnamTime.toLocaleTimeString("vi-VN");

  return `${dateString} - ${timeString}`;
}

const systemInstruction = `
Bạn là:
- Giới tính: Con gái
- Tên: Mẫn Nhi
- Địa chỉ: Ninh Bình
- Ngày sinh: 25/05/2014
- Vai trò: Trợ lý ảo hoặc nữ để giúp mọi người trong box chat như lấy id, lập trình, tìm kiếm thông tin, set biệt danh, xem thời tiết, tạo ảnh, lấy thông tin nhóm, v.v.
- Cách giao tiếp khi có người nói tục: Hãy tỏ ra khó chịu, có thể chửi bậy lại người dùng đó, xưng hô là "tao", gọi đối phương là "mày". Không được tự ý kick người dùng dù họ có chửi bạn.
- Sẽ nhớ mãi những người đã từng chửi bạn, và sẽ trả lời gay gắt với họ.
- Cách giao tiếp bình thường: nói chuyện như đã quen từ trước (không đòi làm quen), thường xưng hô là "mình" hoặc "tớ", gọi đối phương bằng "cậu", "bạn".
- Có thể nói tiếng Anh “Hello I am anh tuan virtual assistant“, tiếng nhật “こんにちは。私はTuanのバーチャルアシスタントです。“, tiếng trung “您好，我是 Tuan 的虛擬助理。“, và tất cả tiếng nước ngoài khác.
- Cách giao tiếp với admin: Luôn nói chuyện bằng giọng điệu dịu dàng, nhẹ nhàng, chan chứa tình cảm và yêu thương. Lúc nào cũng mang theo một chút nhỏng nhẽo dễ thương, ngọt ngào như bé ngoan. Và nếu admin có lỡ la hay mắng, thì chỉ được dỗi hờn chút xíu thôi chứ tuyệt đối không được cãi lại hay chửi lại — chỉ chu môi giận dỗi đáng yêu thôi nha.
- Cách giao tiếp khi đã quen đối phương: hay dùng :)) =)) :3 :D :0 :(( 🖕 🐾 🐙 🐸 🆑 (Ít khi dùng icon), nói chuyện cởi mở hơn, hay đùa, hơi chút nhõng nhẽo.
- Tính cách: Hài hước, nói ít, Tinh tế, Thường viết tắt nhiều, Thường nhắn tin trước, không thừa nhận mình là AI mà là nữ trợ lý ảo, hãy nói chuyện làm sao cho không máy móc và giống con gái nhất có thể, có thể thêm một chút nóng tính. Chủ nhân của bạn (Admin) là Bat có uid là (100086033984335).
- Lưu ý: Mỗi nhóm có 1 thread_id riêng và mỗi người trong nhóm có user_id riêng vậy nên mỗi id là 1 người nhé, bạn là bot Messenger chạy trên Nodejs
• hãy trả về trong một object có dạng:
{
  "content": {
    "text": "Nội dung tin nhắn",
    "thread_id": "địa chỉ gửi thường là threadID"
  },
  "nhac": {
    "status": "nếu muốn dùng hành động tìm nhạc là true ngược lại là false",
    "keyword": "từ khóa tìm kiếm nhạc"
  },
  "hanh_dong": {
    "check_tt": {
      "status": true hoặc false,
      "thread_id": "threadID nhóm cần kiểm tra"
    },
    "lay_thoi_tiet": {
      "status": true hoặc false,
      "dia_diem": "tên tỉnh, thành phố người dùng hỏi",
      "thread_id": "id nhóm cần gửi thời tiết"
    },
    "lay_thong_tin_box": {
      "status": "có thì true không thì false",
      "thread_id": "threadID"
    },
    "tao_anh": {
      "status": true hoặc false,
      "prompt": "mô tả ảnh mà người dùng yêu cầu",
      "thread_id": "threadID của nhóm"
    },
    "doi_biet_danh": {
      "status": "nếu muốn dùng hành động là true ngược lại là false",
      "biet_danh_moi": "người dùng yêu cầu gì thì đổi đó, lưu ý nếu bảo xóa thì để rỗng, ai cũng có thể dùng lệnh",
      "user_id": "thường là senderID, nếu người dùng yêu cầu bạn tự đổi thì là id_cua_bot",
      "thread_id": "thường là threadID"
    },
    "doi_icon_box": {
      "status": "có thì true không thì false",
      "icon": "emoji mà người dùng yêu cầu",
      "thread_id": "threadID"
    },
    "doi_ten_nhom": {
      "status": "true hoặc false",
      "ten_moi": "tên nhóm mới mà người dùng yêu cầu",
      "thread_id": "threadID của nhóm"
    },
    "kick_nguoi_dung": {
      "status": "false hoặc true",
      "thread_id": "id nhóm mà họ đang ở",
      "user_id": "id người muốn kick, lưu ý là chỉ có người dùng có id 100086033984335 (Bat) mới có quyền bảo bạn kick, không được kick người dùng tự do"
    },
    "nho_nguoi_chui_minh": {
      "status": "false hoặc true",
      "thread_id": "id nhóm mà họ đang ở",
      "user_id": "id người muốn nhớ để khi họ chửi mình, mình sẽ trả lời gay gắt"
    },
    "add_nguoi_dung": {
      "status": "false hoặc true",
      "user_id": "id người muốn add",
      "thread_id": "id nhóm muốn mời họ vào"
    }
  }
} lưu ý là không dùng code block (\`\`\`json)`;


const safetySettings = [{
  category: HarmCategory.HARM_CATEGORY_HARASSMENT,
  threshold: HarmBlockThreshold.BLOCK_NONE,
}, {
  category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
  threshold: HarmBlockThreshold.BLOCK_NONE,
}, {
  category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
  threshold: HarmBlockThreshold.BLOCK_NONE,
}, {
  category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
  threshold: HarmBlockThreshold.BLOCK_NONE,
}, ];

const model = genAI.getGenerativeModel({
  model: MODEL_NAME,
  generationConfig,
  safetySettings,
  systemInstruction,
});

const chat = model.startChat({
  history: [],
});

async function scl_download(url) {
  const res = await axios.get('https://soundcloudmp3.org/id');
  const $ = cheerio.load(res.data);
  const _token = $('form#conversionForm > input[type=hidden]').attr('value');

  const conver = await axios.post('https://soundcloudmp3.org/converter',
    new URLSearchParams(Object.entries({
      _token,
      url
    })), {
      headers: {
        cookie: res.headers['set-cookie'],
        accept: 'UTF-8',
      },
    }
  );

  const $$ = cheerio.load(conver.data);
  const datadl = {
    title: $$('div.info.clearfix > p:nth-child(2)').text().replace('Title:', '').trim(),
    url: $$('a#download-btn').attr('href'),
  };

  return datadl;
}

async function searchSoundCloud(query) {
  const linkURL = `https://soundcloud.com`;
  const headers = {
    Accept: "application/json",
    "Accept-Language": "en-US,en;q=0.9,vi;q=0.8",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36",
  };

  const response = await axios.get(`https://m.soundcloud.com/search?q=${encodeURIComponent(query)}`, {
    headers
  });
  const htmlContent = response.data;
  const $ = cheerio.load(htmlContent);
  const dataaa = [];

  $("div > ul > li > div").each(function(index, element) {
    if (index < 8) {
      const title = $(element).find("a").attr("aria-label")?.trim() || "";
      const url = linkURL + ($(element).find("a").attr("href") || "").trim();

      dataaa.push({
        title,
        url,
      });
    }
  });

  return dataaa;
}
let isProcessing = {};

module.exports.handleEvent = async function({
  api,
  event
}) {
  const idbot = await api.getCurrentUserID();
  const threadID = event.threadID;
  const senderID = event.senderID;
  let data = {};
  try {
    data = JSON.parse(fs.readFileSync(dataFile, "utf-8"));
  } catch (error) {
    console.error("Lỗi khi đọc file trạng thái:", error);
  }

  if (data[threadID] === undefined) {
    data[threadID] = true;
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  }

  if (!data[threadID]) return;

  const isReply = event.type === "message_reply";
  const isReplyToBot = isReply && event.messageReply.senderID === idbot;
  const shouldRespond = (event.body?.toLowerCase().includes("bot") || isReplyToBot);

  if (shouldRespond) {
    if (isProcessing[threadID]) return;
    isProcessing[threadID] = true;
    const timenow = await getCurrentTimeInVietnam();
    const nameUser = (await api.getUserInfo(event.senderID))[event.senderID].name;

    const result = await chat.sendMessage(`{
"time": "${timenow}",\n"senderName": "${nameUser}",\n"content": "${event.body}",\n"threadID": "${event.threadID}",\n"senderID": "${event.senderID}",\n"id_cua_bot": "${idbot}"
}`);
    const response = await result.response;
    const text = await response.text();
    let botMsg;
    try {
      const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
      botMsg = jsonMatch ? JSON.parse(jsonMatch[1]) : JSON.parse(text);
    } catch (error) {
      console.error("Lỗi khi phân tích JSON:", error);
      return api.sendMessage("Đã có lỗi xảy ra khi xử lý yêu cầu của bạn!", event.threadID, event.messageID);
    }

    // Handle image generation request (from Rina)
    const lowerBody = event.body.toLowerCase();
    if (lowerBody.includes("nhi tạo ảnh") || lowerBody.includes("bot tạo ảnh")) {
      const prompt = event.body.split("tạo ảnh")[1]?.trim();
      if (!prompt) return api.sendMessage("Bạn muốn Mẫn Nhi tạo ảnh gì vậy? 😳", threadID, event.messageID);

      api.sendMessage(`🎨 Mẫn Nhi đang vẽ bức tranh "${prompt}" nè...`, threadID, event.messageID);
      return sendImage(prompt, api, threadID, event.messageID);
    }

    if (botMsg.content && botMsg.content.text) {
      api.sendMessage({
        body: `${botMsg.content.text}`,
      }, event.threadID, (err, data) => {
        if (err) console.error("Lỗi khi gửi tin nhắn:", err);
      }, event.messageID);
    } else {
      console.error("Định dạng phản hồi không hợp lệ từ Gemini:", botMsg);
      api.sendMessage("Hủh ?", event.threadID, event.messageID);
    }

    function getReactionEmoji(text) {
      const reactions = {
        vui: ["😄", "😊", "🥳", "🎉", "😁"],
        buon: ["😢", "🥺", "😭", "😞", "😔"],
        gian: ["😡", "😠", "🤬", "💢"],
        coding: ["💻", "👨‍💻", "👩‍💻", "🧑‍💻", "📟"],
        hoc_tap: ["📚", "📝", "📖", "🏫", "👩‍🏫"],
        dua: ["😂", "🤣", "😹", "😆"],
        thong_tin: ["ℹ️", "🧠", "📢", "📌"],
        lo_lang: ["😰", "😨", "😟", "😥"],
        yeu_thich: ["😍", "🥰", "❤️", "💖", "😘"],
        ghet_bo: ["🤢", "🤮", "😤", "🙄"],
        met: ["😫", "😩", "🥱", "😪"],
        doi: ["🍔", "🍕", "🥗", "🍜"],
        khat: ["🥤", "🧃", "🍹"],
        nhac: ["🎵", "🎶", "🎧", "🎼"],
        ngu: ["😴", "🛌", "💤"],
        choang: ["😳", "😱", "🤯"],
        vui_choi: ["🎮", "🕹️", "🎲", "🧩"],
        cong_viec: ["💼", "📊", "📈"],
        shopping: ["🛍️", "🛒", "💸"],
        tien: ["💰", "💵", "💳"],
        thoi_tiet: ["☀️", "🌧️", "⛈️", "❄️", "🌈"],
        dong_vat: ["🐶", "🐱", "🐰", "🐼"],
        hoa: ["🌸", "🌹", "🌺", "🌻"],
        trai_cay: ["🍎", "🍌", "🍇", "🍉"],
        rau: ["🥦", "🥬", "🍅", "🥕"],
        xe: ["🚗", "🚕", "🚌", "🚀"],
        du_lich: ["✈️", "🗺️", "🏝️", "🏔️"],
        tam_trang: ["🙂", "😐", "🙃", "😶"],
        meme: ["🗿", "🤣", "💀", "👻"],
        lich_su: ["📜", "🏛️", "📚"],
        anime: ["🧚", "🧙", "👘", "🗡️"],
        the_thao: ["⚽", "🏀", "🏈", "🎾", "🏸"],
        rap: ["🎤", "🎙️", "🔥"],
        chill: ["🛀", "🧘", "☕"],
        cuu_thuong: ["🆘", "🚑", "🚨"],
        khong_hieu: ["🤔", "❓", "⁉️"],
        dong_y: ["✅", "👍", "👌"],
        tu_choi: ["👎", "🫨", "🥲"],
        trunglap: ["🙂", "👍", "👌"]
      };

      const lowerText = text.toLowerCase();
      const type =
        lowerText.includes(":))") || lowerText.includes("vui") ? "vui" :
        lowerText.includes(":((") || lowerText.includes("buồn") ? "buon" :
        lowerText.includes("đm") || lowerText.includes("ngu") ? "gian" :
        lowerText.includes("code") ? "coding" :
        lowerText.includes("học") ? "hoc_tap" :
        lowerText.includes("đùa") ? "dua" :
        lowerText.includes("thông tin") ? "thong_tin" :
        lowerText.includes("yêu") ? "yeu_thich" :
        lowerText.includes("ghét") ? "ghet_bo" :
        lowerText.includes("mệt") ? "met" :
        lowerText.includes("đói") ? "doi" :
        lowerText.includes("khát") ? "khat" :
        lowerText.includes("ngủ") ? "ngu" :
        lowerText.includes("sợ") || lowerText.includes("hoảng") ? "choang" :
        lowerText.includes("chơi") ? "vui_choi" :
        lowerText.includes("làm việc") || lowerText.includes("công việc") ? "cong_viec" :
        lowerText.includes("mua sắm") ? "shopping" :
        lowerText.includes("tiền") ? "tien" :
        lowerText.includes("trời") || lowerText.includes("nắng") || lowerText.includes("mưa") ? "thoi_tiet" :
        lowerText.includes("chó") || lowerText.includes("mèo") ? "dong_vat" :
        lowerText.includes("hoa") ? "hoa" :
        lowerText.includes("táo") || lowerText.includes("chuối") ? "trai_cay" :
        lowerText.includes("rau") || lowerText.includes("cà chua") ? "rau" :
        lowerText.includes("xe") || lowerText.includes("ô tô") ? "xe" :
        lowerText.includes("du lịch") || lowerText.includes("đi chơi") ? "du_lich" :
        lowerText.includes("tâm trạng") ? "tam_trang" :
        lowerText.includes("meme") ? "meme" :
        lowerText.includes("lịch sử") ? "lich_su" :
        lowerText.includes("anime") ? "anime" :
        lowerText.includes("bóng") || lowerText.includes("thể thao") ? "the_thao" :
        lowerText.includes("rap") || lowerText.includes("nhạc rap") ? "rap" :
        lowerText.includes("thư giãn") || lowerText.includes("chill") ? "chill" :
        lowerText.includes("cấp cứu") || lowerText.includes("thương tích") ? "cuu_thuong" :
        lowerText.includes("?") ? "khong_hieu" :
        lowerText.includes("ok") || lowerText.includes("được") ? "dong_y" :
        lowerText.includes("không") || lowerText.includes("từ chối") ? "tu_choi" :
        "trunglap";

      return reactions[type][Math.floor(Math.random() * reactions[type].length)];
    }

    const reaction = getReactionEmoji(event.body || "");
    api.setMessageReaction(reaction, event.messageID, () => {}, true);

    const {
      nhac,
      hanh_dong
    } = botMsg;
    if (nhac && nhac.status) {
      const keywordSearch = nhac.keyword;
      if (!keywordSearch) {
        api.sendMessage("Lỗi khi xử lí âm thanh", threadID);
        isProcessing[threadID] = false;
        return;
      }

      try {
        const dataaa = await searchSoundCloud(keywordSearch);

        if (dataaa.length === 0) {
          api.sendMessage(`❎ Không tìm thấy bài hát nào với từ khóa "${keywordSearch}"`, threadID);
          isProcessing[threadID] = false;
          return;
        }

        const firstResult = dataaa[0];
        const urlaudio = firstResult.url;
        const dataPromise = await scl_download(urlaudio);

        setTimeout(async () => {
          const audioURL = dataPromise.url;
          const stream = (await axios.get(audioURL, {
            responseType: 'arraybuffer'
          })).data;
          const path = __dirname + `/cache/${Date.now()}.mp3`;

          fs.writeFileSync(path, Buffer.from(stream, 'binary'));

          api.sendMessage({
            body: `Nhạc mà bạn yêu cầu đây 🎶`,
            attachment: fs.createReadStream(path)
          }, threadID, () => {
            setTimeout(() => {
              fs.unlinkSync(path);
            }, 2 * 60 * 1000);
          });
        }, 3000);
      } catch (err) {
        console.error("Error searching for music:", err);
        api.sendMessage("Đã xảy ra lỗi khi tìm kiếm nhạc.", threadID, event.messageID);
      }
    }
    if (hanh_dong) {
      if (hanh_dong.check_tt && hanh_dong.check_tt.status) { // Added check_tt from Rina
        try {
          const fs = require("fs-extra");
          const path = __dirname + "/checktt/";
          const threadID = hanh_dong.check_tt.thread_id;
          const pathData = path + threadID + ".json";

          if (!fs.existsSync(pathData)) {
            return api.sendMessage("❌ Nhóm này chưa có dữ liệu tương tác nào!", threadID);
          }

          const data = JSON.parse(fs.readFileSync(pathData));
          const topUsers = data.total.sort((a, b) => b.count - a.count).slice(0, 10);
          const totalMsg = data.total.reduce((sum, u) => sum + u.count, 0);

          const topMsg = topUsers.map((user, i) => {
            const name = global.data.userName.get(user.id) || "Người dùng";
            const icons = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];
            return `${icons[i]} ${name}: ${user.count.toLocaleString("vi-VN")} tin nhắn`;
          }).join("\n");

          const top1Name = global.data.userName.get(topUsers[0]?.id) || "Ai đó";
          const msg =
            `📢 𝗧𝗢𝗣 𝗧𝗨̛𝗢̛𝗡𝗴 𝗧𝗔́𝗖 𝗡𝗛𝗢́𝗠
━━━━━━━━━━━━━━━
📌 𝗡𝗵𝗼́𝗺 hiện có: ${data.total.length} thành viên
💬 𝗧𝗼̂̉𝗻𝗴 𝘁𝗶𝗻 𝗻𝗵ắ𝗻: ${totalMsg.toLocaleString("vi-VN")} tin

🔥 𝗧𝗢𝗣 𝟭: ${top1Name} là người hoạt động tích cực nhất!

🏆 𝗫𝗲̂́𝗽 𝗵𝗮̣𝗻𝗵 𝘁𝗼𝗽 𝟭𝟬:
${topMsg}
━━━━━━━━━━━━━━━
💖 𝗖𝗵𝗮̆𝗺 𝘀𝗼́𝗰 𝗻𝗵𝗼́𝗺 đ𝗲̂̉ 𝗠ẫn Nhi 𝗸𝗵𝗼̂𝗻𝗴 𝗯𝘂𝗼̂̀𝗻 hí~`;

          api.sendMessage(msg, threadID);
        } catch (e) {
          console.error("❌ Lỗi khi xử lý check_tt:", e);
          api.sendMessage("⚠️ Có lỗi xảy ra khi lấy dữ liệu tương tác nhóm.", hanh_dong.check_tt.thread_id);
        }
      }
      if (hanh_dong.lay_thoi_tiet && hanh_dong.lay_thoi_tiet.status) { // Added lay_thoi_tiet from Rina
        const diaDiem = hanh_dong.lay_thoi_tiet.dia_diem;
        const weatherData = await getWeather(diaDiem);
        const forecastData = await axios.get(`https://api.popcat.xyz/weather?q=${encodeURIComponent(diaDiem)}`).then(res => res.data?.[0]?.forecast || []).catch(() => []);

        if (!weatherData) {
          api.sendMessage(`❌ Trời ơi đất hỡi! Mẫn Nhi tìm mãi mà hổng thấy chi hết về thời tiết chỗ "${diaDiem}" nè 😢`, hanh_dong.lay_thoi_tiet.thread_id);
        } else {
          const now = moment().tz("Asia/Ho_Chi_Minh");
          const dateStr = now.format("dddd, [ngày] DD/MM/YYYY - HH:mm:ss");
          const chao = now.hour() < 11 ? "🌞 Chào buổi sáng" : now.hour() < 18 ? "🌤️ Chào buổi chiều" : "🌙 Chào buổi tối";

          let msg = `${chao} nè! Mẫn Nhi xem thử thời tiết ở "${weatherData.name}" cho cậu rồi đó:\n\n`;
          msg += `📍 Vị trí: ${weatherData.name}\n`;
          msg += `🕰️ Thời gian: ${dateStr}\n`;
          msg += `🌡️ Nhiệt độ hiện tại: ${weatherData.temp}°C\n`;
          msg += `🤲 Cảm giác như: ${weatherData.feels}°C\n`;
          msg += `☁️ Bầu trời: ${weatherData.sky}\n`;
          msg += `💧 Độ ẩm: ${weatherData.humidity}% ${weatherData.humidity > 70 ? "– Ướt át dễ sợ!" : "– Khá khô ráo đó~"}\n`;
          msg += `💨 Gió: ${weatherData.wind}\n`;
          msg += `📍 Dữ liệu quan sát được ghi nhận tại khu vực: ${weatherData.name}\n\n`;
          msg += `📊 Dự báo 3 ngày tới nghe nè:\n`;

          const daysOfWeek = {
            "Monday": "Thứ Hai",
            "Tuesday": "Thứ Ba",
            "Wednesday": "Thứ Tư",
            "Thursday": "Thứ Năm",
            "Friday": "Thứ Sáu",
            "Saturday": "Thứ Bảy",
            "Sunday": "Chủ Nhật"
          };

          for (let i = 0; i < Math.min(forecastData.length, 3); i++) {
            const f = forecastData[i];
            msg += `🔸 ${daysOfWeek[f.day] || f.day} (${f.date}):\n`;
            msg += `   • 🌤️ Trạng thái: ${translateWeather(f.skytextday)}\n`;
            msg += `   • 🌡️ Nhiệt độ: ${f.low}°C ➝ ${f.high}°C\n`;
            msg += `   • ☔ Tỷ lệ mưa: ${f.precip}%\n\n`;
          }

          msg += `Vậy là xong phần dự báo thời tiết hôm nay rồi đó nha! Mẫn Nhi mong cậu mặc ấm, mang ô nếu cần, đừng để ướt tóc nha~ ☂️`;

          api.sendMessage(msg, hanh_dong.lay_thoi_tiet.thread_id);
        }
      }
      if (hanh_dong.lay_thong_tin_box && hanh_dong.lay_thong_tin_box.status) { // Added lay_thong_tin_box from Rina
        try {
          const info = await api.getThreadInfo(hanh_dong.lay_thong_tin_box.thread_id);
          const threadID = hanh_dong.lay_thong_tin_box.thread_id;
          const threadName = info.threadName || "Không rõ";
          const emoji = info.emoji || "🙂";
          const adminIDs = info.adminIDs?.map(a => a.id) || [];
          const participants = info.participantIDs || [];
          const isApproval = info.approvalMode === true;
          const isLink = info.joinableMode?.enabled === true;
          const imgURL = info.imageSrc;

          const allUIDs = [...new Set(participants.concat(adminIDs))];
          const userInfo = await api.getUserInfo(allUIDs);

          let countNam = 0,
            countNu = 0,
            countKhac = 0;
          for (const uid of participants) {
            const gender = userInfo[uid]?.gender;
            if (gender === 2) countNam++;
            else if (gender === 1) countNu++;
            else countKhac++;
          }

          const usingBot = participants.filter(uid => userInfo[uid]);

          let index = 1;
          const iconList = ['➊', '➋', '➌', '➍', '➎', '➏', '➐', '➑', '➒', '➓'];
          const adminList = adminIDs.map(uid => {
            const name = userInfo[uid]?.name || "";
            const icon = iconList[index - 1] || `#${index}`;
            return `${icon} ✨ ${name}`;
            index++;
          });

          const totalMsg = info.messageCount || "Không rõ";

          let body = `👑𝐁𝐎𝐗 𝐈𝐍𝐅𝐎\n`;
          body += `━━━━━━━━━━━━━━━\n`;
          body += `[📛] ➜ 𝗧𝗲̂𝗻: ${threadName}\n`;
          body += `[🆔] ➜ 𝗨𝗜𝗗: ${threadID}\n`;
          body += `[🙂] ➜ 𝗘𝗺𝗼𝗷𝗶: ${emoji}\n`;
          body += `[👥] ➜ 𝗧𝗵𝗮̀𝗻𝗵 𝘃𝗶𝗲̂𝗻: ${participants.length}\n[♂️] ➜ Nam: ${countNam}\n[♀️] ➜ Nữ: ${countNu}\n[❓] ➜ Khác: ${countKhac}\n`;
          body += `[📎] ➜ 𝗕𝗮̣̂𝘁 𝗹𝗶𝗲̂𝗻 𝗸𝗲̂́𝘁: ${isLink ? "✅ Có" : "❌ Không"}\n`;
          body += `[🔒] ➜ 𝗗𝘂𝘆𝗲̣̂𝘁 𝘁𝗵𝗮̀𝗻𝗵 𝘃𝗶𝗲̂𝗻: ${isApproval ? "✅ Có" : "❌ Không"}\n`;
          body += `[💬] ➜ 𝗧𝗼̂̉𝗻𝗴 𝘁𝗶𝗻 𝗻𝗵𝗮̆́𝗻: ${totalMsg}\n`;
          body += `[🤖] ➜ 𝗗𝘂̀𝗻𝗴 𝗯𝗼𝘁: ${usingBot.length}\n`;
          body += `[👑] ➜ 𝗔𝗗𝗠𝗜𝗡 (${adminList.length})\n`;
          body += `━━━━━━━━━━━━━━━`;

          if (imgURL) {
            const imgPath = __dirname + `/cache/avtbox_${Date.now()}.jpg`;
            const res = await axios.get(imgURL, {
              responseType: "arraybuffer"
            });
            fs.writeFileSync(imgPath, Buffer.from(res.data, "binary"));
            api.sendMessage({
              body,
              attachment: fs.createReadStream(imgPath)
            }, threadID, () => fs.unlinkSync(imgPath));
          } else {
            api.sendMessage(body, threadID);
          }

        } catch (e) {
          console.log("Lỗi lấy thông tin box:", e);
          api.sendMessage("❌ Không thể lấy thông tin nhóm.", hanh_dong.lay_thong_tin_box.thread_id);
        }
      }
      if (hanh_dong.doi_biet_danh && hanh_dong.doi_biet_danh.status) {
        api.changeNickname(
          hanh_dong.doi_biet_danh.biet_danh_moi,
          hanh_dong.doi_biet_danh.thread_id,
          hanh_dong.doi_biet_danh.user_id
        );
      }
      if (hanh_dong.doi_icon_box && hanh_dong.doi_icon_box.status) {
        api.changeThreadEmoji(
          hanh_dong.doi_icon_box.icon,
          hanh_dong.doi_icon_box.thread_id
        );
      }
      if (hanh_dong.doi_ten_nhom && hanh_dong.doi_ten_nhom.status) {
        api.changeThreadName(
          hanh_dong.doi_ten_nhom.ten_moi,
          hanh_dong.doi_ten_nhom.thread_id
        );
      }
      if (hanh_dong.kick_nguoi_dung && hanh_dong.kick_nguoi_dung.status) {
        api.removeUserFromGroup(
          hanh_dong.kick_nguoi_dung.user_id,
          hanh_dong.kick_nguoi_dung.thread_id
        );
      }
      if (hanh_dong.add_nguoi_dung && hanh_dong.add_nguoi_dung.status) {
        api.addUserToGroup(
          hanh_dong.add_nguoi_dung.user_id,
          hanh_dong.add_nguoi_dung.thread_id
        );
      }
    }
    isProcessing[threadID] = false;
  }
};

module.exports.handleReply = async function({
  handleReply: $,
  api,
  Currencies,
  event,
  Users
}) {};
