let gaiUrls = require("./../../curumi/datajson/vdgai.json");
let animeUrls = require("./../../curumi/datajson/vdani.json");
let cosUrls = require("./../../curumi/datajson/vdcos.json");
let ffUrls = require("./../../curumi/datajson/vdff.json");
let batUrls = require("./../../curumi/datajson/vdbat.json");

const axios = require("axios");
const fs = require("fs");

class Command {
constructor(config) {
    this.config = config;
    global.vdgai = [];
    global.anime = [];
    global.vdcos = [];
    global.vdff = [];
    global.vdbat = [];
};

async onLoad(o) {  
    let status = false;  

    if (!global.client.xx) global.client.xx = setInterval(async () => {  
        if (
            status ||
            global.vdgai.length > 10 ||
            global.anime.length > 10 ||
            global.vdcos.length > 10 ||
            global.vdff.length > 10 ||
            global.vdbat.length > 10
        ) return;

        status = true;

        try {
            let gaiList = [...gaiUrls].sort(() => 0.5 - Math.random()).slice(0, 5);
            let animeList = [...animeUrls].sort(() => 0.5 - Math.random()).slice(0, 5);
            let cosList = [...cosUrls].sort(() => 0.5 - Math.random()).slice(0, 5);
            let ffList = [...ffUrls].sort(() => 0.5 - Math.random()).slice(0, 5);
            let batList = [...batUrls].sort(() => 0.5 - Math.random()).slice(0, 5);

            let gaiRes = await Promise.all(gaiList.map(url => upload(url)));
            let animeRes = await Promise.all(animeList.map(url => upload(url)));
            let cosRes = await Promise.all(cosList.map(url => upload(url)));
            let ffRes = await Promise.all(ffList.map(url => upload(url)));
            let batRes = await Promise.all(batList.map(url => upload(url)));

            global.vdgai.push(...gaiRes);
            global.anime.push(...animeRes);
            global.vdcos.push(...cosRes);
            global.vdff.push(...ffRes);
            global.vdbat.push(...batRes);
        } catch (err) {
            console.error("Lỗi upload:", err);
        }

        status = false;
    }, 5000);

    async function streamURL(url, type) {
        const cacheDir = __dirname + '/cache';
        if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir);
        return axios.get(url, {
            responseType: 'arraybuffer'
        }).then(res => {
            const path = `${cacheDir}/${Date.now()}.${type}`;
            fs.writeFileSync(path, res.data);
            setTimeout(p => fs.unlinkSync(p), 60000, path);
            return fs.createReadStream(path);
        });
    }

    async function upload(url) {
        return o.api.httpPostFormData(
            'https://upload.facebook.com/ajax/mercury/upload.php',
            { upload_1024: await streamURL(url, 'mp4') }
        ).then(res =>
            Object.entries(JSON.parse(res.replace('for (;;);', '')).payload?.metadata?.[0] || {})[0]
        );
    }
};

async run(o) {
    const send = msg => new Promise(r => o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res || err), o.event.messageID));
    const text = o.event.body?.toLowerCase()?.trim() || "";

    // Xử lý reload video
    if (["reload", "nạp lại", "reset", "tải lại"].some(t => text.includes(t))) {
        await send("⏳ Đang nạp lại danh sách video, đợi xíu nha...");
        global.vdgai = [];
        global.anime = [];
        global.vdcos = [];
        global.vdff = [];
        global.vdbat = [];
        await this.onLoad(o);
        return send("✅ Đã nạp lại video xong rồi đó! Gửi tiếp để nhận video mới nha~");
    }

    let source;
    let label;

    if (text.includes("anime")) {
        source = global.anime;
        label = "vdanime";
    } else if (text.includes("cos")) {
        source = global.vdcos;
        label = "vdcos";
    } else if (text.includes("ff")) {
        source = global.vdff;
        label = "vdff";
    } else if (text.includes("bat")) {
        source = global.vdbat;
        label = "vdbat";
    } else {
        source = global.vdgai;
        label = "vdgai";
    }

    if (!source.length) {
        await this.onLoad(o);
        return send("Đợi một lát nhé, video đang được chuẩn bị...");
    }

    let attachment = source.splice(0, 1)[0];
    if (!attachment) return send("Video lỗi, thử lại sau!");

    send({
        body: `🎬 Gửi video từ nhóm **${label}**`,
        attachment
    });
}

}

module.exports = new Command({
    name: "global",
    version: "1.0.7",
    hasPermssion: 2,
    credits: "DC-Nam + Bat",
    description: "Gửi video ngẫu nhiên (gái / anime / cos / ff / bat) + reload danh sách",
    commandCategory: "Tiện ích",
    usages: "[gái | anime | cos | ff | bat | reload]",
    cooldowns: 0,
});