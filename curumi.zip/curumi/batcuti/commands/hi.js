module.exports.config = {
  name: "hello",
  version: "3.0.0",
  hasPermssion: 1,
  credit: "Vtuan",
  description: "hi gửi sticker and hình ảnh",
  commandCategory: "group",
  usages: "[text]",
  cooldowns: 5
}

module.exports.handleEvent = async ({ api, event, Threads, Users }) => {
  const axios = require('axios');
  const request = require('request');
  const fs = require("fs");
  const moment = require("moment-timezone");

  let KEY = [
    "hello", "hi", "hai", "chào", "chao", "hí", "híí", "hì", "hìì", "lô", "hii", "helo", "hê nhô",
    "hi mng", "hiii mng", "hiii", "hiiii", "haii", "chàoo", "hello mn", "chào mn", "chào mng",
    "hi mn", "hii mn", "hiii mn", "halo", "haloo", "ha lo", "ha loo"
  ];

  let thread = global.data.threadData.get(event.threadID) || {};
  if (typeof thread["hi"] == "undefined" || thread["hi"] == false) return;

  if (event.body && KEY.includes(event.body.toLowerCase())) {
    let hours = moment.tz('Asia/Ho_Chi_Minh').format('HHmm');
    let data2 = [
      "Happy =))", "vui vẻ :3", "hạnh phúc ❤", "nhiều niềm vui 😘"
    ];
    let text = data2[Math.floor(Math.random() * data2.length)];
    let session = (
      hours > 0 && hours <= 400 ? "sáng tinh mơ" :
      hours > 401 && hours <= 700 ? "sáng sớm" :
      hours > 701 && hours <= 1000 ? "sáng" :
      hours > 1001 && hours <= 1200 ? "trưa" :
      hours > 1201 && hours <= 1700 ? "chiều" :
      hours > 1701 && hours <= 1800 ? "chiều tà" :
      hours > 1801 && hours <= 2100 ? "tối" :
      hours > 2101 && hours <= 2400 ? "tối muộn" :
      "lỗi"
    );

    // Lấy tên người dùng gửi lệnh
    let name = await Users.getNameUser(event.senderID);

    // Tạo mentions để tag người dùng trong tin nhắn
    let mentions = [{ tag: name, id: event.senderID }];

    // Lấy 2 ảnh ngẫu nhiên từ file JSON
    const tdung = require('./../../curumi/datajson/gaivip.json');
    let image1 = tdung[Math.floor(Math.random() * tdung.length)].trim();
    let image2 = tdung[Math.floor(Math.random() * tdung.length)].trim();

    function downloadImage(url, filename, callback) {
      request(url).pipe(fs.createWriteStream(__dirname + `/${filename}`)).on("close", callback);
    }

    let callback = function () {
      return api.sendMessage({
        body: `Xin chào ${name}, Chúc bạn một buổi ${session} ${text}`,
        mentions: mentions,
        attachment: [
          fs.createReadStream(__dirname + `/1.png`),
          fs.createReadStream(__dirname + `/2.png`)
        ]
      }, event.threadID, () => {
        // Xóa file sau khi gửi
        fs.unlinkSync(__dirname + `/1.png`);
        fs.unlinkSync(__dirname + `/2.png`);
      }, event.messageID);
    };

    // Tải ảnh rồi mới gửi
    downloadImage(image1, '1.png', () => {
      downloadImage(image2, '2.png', callback);
    });
  }
}

module.exports.languages = {
  "vi": {
    "on": "Bật",
    "off": "Tắt",
    "successText": "hello thành công",
  },
  "en": {
    "on": "on",
    "off": "off",
    "successText": "hello success!",
  }
}

module.exports.run = async ({ event, api, Threads, getText }) => {
  let { threadID, messageID } = event;
  let data = (await Threads.getData(threadID)).data;
  data["hi"] = !(data["hi"] === true);
  await Threads.setData(threadID, { data });
  global.data.threadData.set(threadID, data);
  return api.sendMessage(`${data["hi"] ? getText("on") : getText("off")} ${getText("successText")}`, threadID, messageID);
}