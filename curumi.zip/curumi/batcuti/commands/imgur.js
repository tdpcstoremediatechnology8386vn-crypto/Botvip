const axios = require("axios");
const FormData = require("form-data");

module.exports = {
  config: {
    name: "i",
    version: "1.3",
    hasPermssion: 0,
    credits: "bat",
    description: "Upload link imgur lên catbox",
    commandCategory: "Tiện ích",
    usages: "[link imgur hoặc reply file]",
    cooldowns: 3,
  },

  run: async function ({ api, event }) {
    const { threadID, messageID, messageReply, type, body } = event;
    const send = (msg) => api.sendMessage(msg, threadID, messageID);
    let msg = "";

    // Kiểm tra định dạng link Imgur hợp lệ
    const isValidMediaLink = (url) =>
      /^https?:\/\/(?:i\.)?imgur\.com\/\w+\.(jpg|jpeg|png|gif|mp4|webm)$/i.test(url);

    // Làm sạch các link: bỏ dấu " và , và query string nếu có
    const cleanLinks = (text) => {
      const links = text.match(/https?:\/\/[^\s"]+/g) || [];
      return links.map(link =>
        link.replace(/^"|"$/g, "")     // bỏ dấu "
            .replace(/,+$/, "")        // bỏ dấu ,
            .replace(/\?.*$/, "")      // bỏ query string nếu có
      );
    };

    // Upload link tới catbox
    const uploadToCatbox = async (url) => {
      const form = new FormData();
      form.append("reqtype", "urlupload");
      form.append("userhash", "");
      form.append("url", url);

      try {
        const res = await axios.post("https://catbox.moe/user/api.php", form, {
          headers: form.getHeaders(),
        });
        return res.data.startsWith("https://") ? res.data : null;
      } catch {
        return null;
      }
    };

    // === Nếu reply file ===
    if (type === "message_reply" && messageReply?.attachments?.length > 0) {
      for (const file of messageReply.attachments) {
        const result = await uploadToCatbox(file.url);
        msg += result ? `"${result}",\n` : `❌ Không thể upload file: ${file.url}\n`;
      }
      return send(msg);
    }

    // === Nếu gửi link imgur ===
    if (body) {
      const links = cleanLinks(body);
      const imgurLinks = links.filter(isValidMediaLink);

      if (imgurLinks.length > 0) {
        for (const url of imgurLinks) {
          const result = await uploadToCatbox(url);
          msg += result ? `"${result}",\n` : `❌ Không thể upload link: ${url}\n`;
        }
        return send(msg);
      }
    }

    return send("⚠️ Vui lòng reply ảnh/video hoặc gửi link Imgur hợp lệ (.jpg, .png, .mp4, .gif, .webm)");
  },
};