const request = require("request");
const fs = require("fs");
const axios = require("axios");

module.exports.config = {
  name: "dỗi",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Kaneki (mod by Nhi Mẫn)",
  description: "Dỗi người bạn tag",
  commandCategory: "group",
  usages: "[tag]",
  cooldowns: 5,
};

module.exports.run = async ({ api, event }) => {
  const link = ["https://i.supaimg.com/a954b35b-83b4-402e-908a-26d895665edb.jpg"]
  const mention = Object.keys(event.mentions);
  if (!mention.length) return api.sendMessage("Bạn đang dỗi ai? Tag họ vào chớ 😠", event.threadID, event.messageID);

  const tag = event.mentions[mention[0]].replace("@", "");
  const callback = () => {
    api.sendMessage({
      body: `${tag} huhu, mình dỗi bạn rồi đó 😤`,
      mentions: [{
        tag: tag,
        id: mention[0]
      }],
      attachment: fs.createReadStream(__dirname + "/cache/doi.jpg")
    }, event.threadID, () => fs.unlinkSync(__dirname + "/cache/doi.jpg"));
  };

  request(encodeURI(link[Math.floor(Math.random() * link.length)]))
    .pipe(fs.createWriteStream(__dirname + "/cache/doi.jpg"))
    .on("close", callback);
};