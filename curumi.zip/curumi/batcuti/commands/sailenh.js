const fs = require("fs");
const fsp = require("fs/promises");
const axios = require("axios");
const path = require("path");

const modePath = path.join(__dirname, "../../batcuti/commands/data/gai_mode.json");

module.exports.config = {
  name: "",
  version: "1.1.0",
  hasPermssion: 0,
  credits: "DC-Nam (mod by bat + mod by Nhi)",
  description: "Gửi random video gái + uptime + thính hoặc chỉ uptime",
  commandCategory: "Tiện ích",
  usages: "[mode]",
  cooldowns: 5
};

module.exports.run = async ({ api, event, args, Users }) => {
  const { threadID, messageID, senderID } = event;

  // Đọc chế độ từ file JSON
  let modeData = {};
  try {
    modeData = JSON.parse(await fsp.readFile(modePath, "utf-8"));
  } catch {
    modeData = {};
  }

  const bodyMode = modeData[threadID] || "full";

  try {
    const t = process.uptime();
    const h = Math.floor(t / 3600);
    const m = Math.floor((t % 3600) / 60);
    const s = Math.floor(t % 60);
    const uptimeStr = `${h}h ${m}m ${s}s`;

    const videoSource = global.videoSource || "vdgai";
    const attachment = global[videoSource]?.splice(0, 1) || [];

    if (attachment.length === 0) {
      return api.sendMessage("⚠️ Không có video khả dụng!", threadID, messageID);
    }

    let bodyText = "";

    if (bodyMode === "full") {
      const thinhRes = await axios.get('https://raw.githubusercontent.com/tuannr10/lekhanh/refs/heads/main/Data_Vtuan/datajson/thinh.json');
      const thinhList = Object.values(thinhRes.data.data);
      const randomThinh = thinhList[Math.floor(Math.random() * thinhList.length)];

      const userName = await Users.getNameUser(senderID);
      bodyText = `Hi ${userName} 🧸\nTime on: ${uptimeStr}\nThính: ${randomThinh}`;
    } else {
      bodyText = `${uptimeStr}`;
    }

    api.sendMessage({ body: bodyText, attachment }, threadID, (err, message) => {
      if (!err) {
        setTimeout(() => {
          if (message?.messageID) api.unsendMessage(message.messageID);
        }, 40000);
      }
    }, messageID);

  } catch (err) {
    console.error("Lỗi gai:", err);
    api.sendMessage("⚠️ Lỗi khi xử lý video!", threadID, messageID);
  }
};