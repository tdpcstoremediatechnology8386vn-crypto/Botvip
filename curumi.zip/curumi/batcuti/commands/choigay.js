const fs = require("fs");
const axios = require("axios");
const path = require("path");

module.exports.config = {
  name: "choigay",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Kaneki (mod by Nhi Mẫn)",
  description: "choi gay người bạn tag",
  commandCategory: "Tình cảm",
  usages: "[tag]",
  cooldowns: 5,
};

module.exports.run = async ({ api, event }) => {
  const link = ["https://files.catbox.moe/ylekct.gif"];
  const mention = Object.keys(event.mentions);

  if (!mention.length) {
    return api.sendMessage("Bạn muốn đụbai? Tag họ vào chớ 😠", event.threadID, event.messageID);
  }

  const tag = event.mentions[mention[0]].replace("@", "");
  const cacheDir = path.join(__dirname, "cache");
  const filePath = path.join(cacheDir, "doi.gif");

  // Tạo thư mục cache nếu chưa có
  if (!fs.existsSync(cacheDir)) {
    fs.mkdirSync(cacheDir);
  }

  try {
    // Tải file gif từ URL
    const response = await axios.get(link[0], { responseType: "arraybuffer" });
    fs.writeFileSync(filePath, response.data);

    // Gửi ảnh kèm tin nhắn
    api.sendMessage({
      body: `${tag} 𝗔𝗻𝗵 𝗻𝗮̆̀𝗺 𝘁𝗿𝗲̂𝗻 𝗲𝗺 𝘁𝗵𝗶̀ 𝗻𝗮̆̀𝗺 𝗱𝘂̛𝗼̛́𝗶, 𝟮 𝗰𝗵𝘂́𝗻𝗴 𝗺𝗶̀𝗻𝗵 𝗰𝗵𝗼̛𝗶 𝗴𝗮𝘆 𝘁𝗵𝗶̀ 𝗰𝗼́ 𝗴𝗶̀ 𝗹𝗮̀ 𝘀𝗮𝗶 🌈`,
      mentions: [{
        tag: tag,
        id: mention[0]
      }],
      attachment: fs.createReadStream(filePath)
    }, event.threadID, () => fs.unlinkSync(filePath)); // Xoá file sau khi gửi xong
  } catch (err) {
    console.error("Lỗi khi tải hoặc gửi file:", err);
    api.sendMessage("Đã xảy ra lỗi khi tải ảnh, thử lại sau nhé.", event.threadID, event.messageID);
  }
};