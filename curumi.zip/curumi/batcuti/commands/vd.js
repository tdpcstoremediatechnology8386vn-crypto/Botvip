const fs = require("fs");
const path = require("path").join(__dirname, "data", "vd.json");
const adminIDs = ["100086033984335"]; // Thay UID admin bot tại đây

// Tạo thư mục data nếu chưa tồn tại
if (!fs.existsSync(require("path").join(__dirname, "data"))) {
  fs.mkdirSync(require("path").join(__dirname, "data"));
}

// Tạo file mặc định nếu chưa có
if (!fs.existsSync(path)) {
  fs.writeFileSync(path, JSON.stringify({}, null, 2));
}

module.exports.config = {
  name: "vd",
  version: "2.6",
  hasPermssion: 0,
  credits: "anhthu",
  description: "Tự động gửi video/ảnh theo từ khóa (admin nhóm bật/tắt)",
  commandCategory: "Admin",
  usages: "vd on/off/list/clean (reply số thứ tự để on/off nhóm đó)",
  cooldowns: 3,
};

const triggerAnime = ["anime", "vdanime"];
const triggerGai = ["gái", "vdgai"];
const triggerTrai = ["trai", "vdtrai"];
const triggerCosplay = ["cos", "vdcosplay", "vdcos"];
const triggerFF = ["ff", "vdff", "🔥", "free fire"];
const triggerBat = ["bat", "còi", "bi"];

function loadStatus() {
  return JSON.parse(fs.readFileSync(path, "utf-8"));
}

function saveStatus(data) {
  fs.writeFileSync(path, JSON.stringify(data, null, 2));
}

function unsendAfterDelay(api, messageID, threadID, delay = 40000) {
  setTimeout(() => {
    api.unsendMessage(messageID);
  }, delay);
}

async function isAdmin(api, threadID, userID) {
  try {
    const threadInfo = await api.getThreadInfo(threadID);
    const threadAdmins = threadInfo.adminIDs ? threadInfo.adminIDs.map(ad => ad.id) : [];
    return threadAdmins.includes(userID) || threadInfo.ownerID === userID || adminIDs.includes(userID);
  } catch {
    return false;
  }
}

module.exports.handleEvent = async function ({ api, event }) {
  if (!event.body) return;
  const status = loadStatus();
  const message = event.body.toLowerCase();
  const threadID = event.threadID;

  if (status[threadID] === false) return;

  const sendAndUnsend = (body, attachment) => {
    api.sendMessage({ body, attachment }, threadID, (err, info) => {
      if (!err) unsendAfterDelay(api, info.messageID, threadID);
    }, event.messageID);
  };

  if (triggerAnime.includes(message)) {
    return sendAndUnsend(" ", global.anime.splice(0, 1));
  }

  if (triggerGai.includes(message)) {
    return sendAndUnsend(" ", global.vdgai.splice(0, 1));
  }

  if (triggerTrai.includes(message)) {
    return sendAndUnsend(" ", global.vdtrai.splice(0, 1));
  }

  if (triggerCosplay.includes(message)) {
    return sendAndUnsend(" ", global.vdcos.splice(0, 1));
  }

  if (triggerFF.includes(message)) {
    return sendAndUnsend(" ", global.vdff.splice(0, 1));
  }

  if (triggerBat.includes(message)) {
    const name = global.data.userName.get(event.senderID) || "đồ dốt";
    return sendAndUnsend(`kêu cc ${name}`, global.vdbat.splice(0, 1));
  }
};

module.exports.run = async function ({ api, event, args }) {
  const status = loadStatus();
  const threadID = event.threadID;
  const messageID = event.messageID;
  const senderID = event.senderID;

  const currentStatus = status[threadID] === true ? "ON" : "OFF";

  if (!args[0]) {
    return api.sendMessage(`Trạng thái VD của nhóm bạn: ${currentStatus}\nDùng: vd on | vd off | vd list | vd clean`, threadID, messageID);
  }

  if (args[0] === "on" || args[0] === "off") {
    const admin = await isAdmin(api, threadID, senderID);
    if (!admin) {
      return api.sendMessage(`⛔ Chỉ admin nhóm hoặc admin bot mới được bật/tắt tính năng này!\nTrạng thái hiện tại: ${currentStatus}`, threadID, messageID);
    }
  }

  if (args[0] === "on") {
    status[threadID] = true;
    saveStatus(status);
    api.setMessageReaction("✅", messageID, () => { }, true);
    return;
  }

  if (args[0] === "off") {
    status[threadID] = false;
    saveStatus(status);
    api.setMessageReaction("✅", messageID, () => { }, true);
    return;
  }

  if (args[0] === "list") {
    try {
      const allThreads = await api.getThreadList(100, null, ["INBOX"]);
      const groupThreads = allThreads.filter(thread => thread.isGroup && thread.name);

      if (groupThreads.length === 0)
        return api.sendMessage("Bot không tham gia nhóm nào cả.", threadID, messageID);

      let msg = "📋 Tên nhóm & trạng thái VD:\n\n";
      let count = 0;

      for (const thread of groupThreads) {
        count++;
        const threadStatus = status[thread.threadID] === true ? "✅" : "❌";
        msg += `${count}. ${thread.name} (${threadStatus})\n`;
      }

      msg += `\n📌 Reply:\n• Số (vd: 1 2 3) để bật nhóm\n• "all" để bật tất cả\n• "off" để tắt tất cả`;

      return api.sendMessage(
        msg,
        threadID,
        (error, info) => {
          if (error) return console.error(error);
          if (!global.client.handleReply) global.client.handleReply = [];
          global.client.handleReply.push({
            type: "vd_list_toggle",
            name: module.exports.config.name,
            author: senderID,
            messageID: info.messageID,
            threads: groupThreads.map(t => t.threadID)
          });
        },
        messageID
      );
    } catch (err) {
      console.error(err);
      return api.sendMessage("❌ Lỗi khi lấy danh sách nhóm.", threadID, messageID);
    }
  }

  if (args[0] === "clean") {
    const admin = adminIDs.includes(senderID);
    if (!admin) return api.sendMessage("⛔ Chỉ admin bot mới được dùng lệnh này!", threadID, messageID);

    const threads = Object.keys(status);
    let removedCount = 0;

    for (const tid of threads) {
      try {
        await api.getThreadInfo(tid);
      } catch (e) {
        delete status[tid];
        removedCount++;
      }
    }

    saveStatus(status);
    return api.sendMessage(`🧹 Đã xoá ${removedCount} nhóm đã out khỏi danh sách cài đặt VD.`, threadID, messageID);
  }

  return api.sendMessage(`❌ Sai cú pháp. Trạng thái VD của nhóm bạn: ${currentStatus}\nDùng: vd on | vd off | vd list | vd clean`, threadID, messageID);
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  if (handleReply.type !== "vd_list_toggle") return;
  if (event.senderID !== handleReply.author) return;

  const status = loadStatus();
  const reply = event.body.trim().toLowerCase();
  const senderID = event.senderID;

  const isAuthorized = await isAdmin(api, event.threadID, senderID);
  if (!isAuthorized) {
    return api.sendMessage("⛔ Bạn không có quyền thực hiện hành động này!", event.threadID, event.messageID);
  }

  let updatedCount = 0;

  if (reply === "all") {
    for (const tid of handleReply.threads) {
      if (!status[tid]) {
        status[tid] = true;
        updatedCount++;
      }
    }
    saveStatus(status);
    api.setMessageReaction("✅", event.messageID, () => { }, true);
    return;
  }

  if (reply === "off") {
    for (const tid of handleReply.threads) {
      if (status[tid]) {
        status[tid] = false;
        updatedCount++;
      }
    }
    saveStatus(status);
    api.setMessageReaction("✅", event.messageID, () => { }, true);
    return;
  }

  const indices = reply.split(/\s+/).map(x => parseInt(x)).filter(x => !isNaN(x) && x >= 1 && x <= handleReply.threads.length);
  if (indices.length === 0) {
    return api.sendMessage("❌ Số thứ tự không hợp lệ!", event.threadID, event.messageID);
  }

  for (const index of indices) {
    const tid = handleReply.threads[index - 1];
    if (!status[tid]) {
      status[tid] = true;
      updatedCount++;
    }
  }

  saveStatus(status);
  api.setMessageReaction("✅", event.messageID, () => { }, true);
};