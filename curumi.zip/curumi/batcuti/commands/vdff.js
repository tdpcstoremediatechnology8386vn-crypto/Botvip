const axios = require("axios");

module.exports.config = {
  name: "ff",
  version: "2.0.5",
  hasPermssion: 0,
  credits: "Tpk | mod by Bat",
  description: "Gửi video vdff",
  commandCategory: "Tiện ích",
  usages: "",
  cooldowns: 0
};

const fallbackUrls = [
    "https://files.catbox.moe/e16dz1.mp4",
    "https://files.catbox.moe/g0ij3a.mp4",
    "https://files.catbox.moe/4nkcj2.mp4",
    "https://files.catbox.moe/buyaay.mp4",
    "https://files.catbox.moe/p6xycq.mp4",
    "https://files.catbox.moe/jk9joa.mp4",
    "https://files.catbox.moe/detntz.mp4",
    "https://files.catbox.moe/mie2zm.mp4",
    "https://files.catbox.moe/mz0yqj.mp4"
  ];

module.exports.run = async ({ api, event }) => {
  const url = fallbackUrls[Math.floor(Math.random() * fallbackUrls.length)];

  try {
    const stream = (await axios.get(url, { responseType: "stream" })).data;
    return api.sendMessage({
      body: " ",
      attachment: stream
    }, event.threadID, event.messageID);
  } catch (error) {
    console.error("Lỗi tải video:", error.message);
    return api.sendMessage("Không thể tải video. Hãy thử lại sau.", event.threadID, event.messageID);
  }
};