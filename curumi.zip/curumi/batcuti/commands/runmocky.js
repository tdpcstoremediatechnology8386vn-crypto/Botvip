const axios = require('axios');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  config: {
    name: 'r',
    version: '0.0.5',
    hasPermssion: 3,
    credits: 'DC-Nam & Satoru',
    description: '',
    commandCategory: 'Admin',
    usages: '',
    usePrefix: true,
    images: [],
    cooldowns: 3,
  },
  run: async function({ api, event, args }) {
    const send = msg => new Promise(r => api.sendMessage(msg, event.threadID, (err, res) => r(res), event.messageID));

    if (args.length === 0) {
      return send(`Vui lòng cung cấp nội dung văn bản, tên file để export hoặc tên file và URL để tải nội dung. Ví dụ: \n${this.config.usages}`);
    }

    const firstArg = args[0];
    const secondArg = args[1];

    // Scenario 1: Tải nội dung từ URL vào file (ví dụ: /note my_file.js https://api.satoru.site/api/note/uuid-raw)
    if (firstArg && secondArg && /^https?:\/\//.test(secondArg)) {
      const filePath = `${__dirname}/${firstArg}`;
      try {
        const { data: content } = await axios.get(secondArg, {
          responseType: 'text',
          headers: { 'User-Agent': 'fetch' }
        });
        fs.writeFileSync(filePath, content);
        return send(`✅ Đã tải và cập nhật file "${firstArg}" thành công từ URL:\n${secondArg}`);
      } catch (downloadError) {
        console.error("Lỗi khi tải nội dung từ URL:", downloadError);
        return send(`❌ Lỗi khi tải nội dung từ URL: ${downloadError.message}`);
      }
    }

    // Scenario 2: Upload file cục bộ lên Satoru.site (ví dụ: /note my_file.js)
    const potentialFilePath = `${__dirname}/${firstArg}`;
    if (fs.existsSync(potentialFilePath) && !secondArg) { // Kiểm tra nếu là file tồn tại và không có đối số thứ hai (không phải URL để tải)
      const uuid = uuidv4();
      const editUrl = `https://api.satoru.site/api/note/${uuid}`;
      const rawUrl = `https://api.satoru.site/api/note/${uuid}-raw`;
      const fileContent = fs.readFileSync(potentialFilePath, 'utf8');

      try {
        await axios.put(editUrl, fileContent, {
          headers: { 'content-type': 'text/plain; charset=utf-8' }
        });
        return send(rawUrl);
      } catch (uploadError) {
        console.error("Lỗi khi upload file lên Satoru.site:", uploadError);
        return send(`❌ Lỗi khi upload file "${firstArg}": ${uploadError.message}`);
      }
    }

    // Scenario 3: Upload nội dung văn bản trực tiếp lên Satoru.site (ví dụ: /note Hello world!)
    // Nếu không phải là lệnh tải file từ URL và không phải là file cục bộ để upload, thì coi là nội dung văn bản.
    const textContent = args.join(" ");
    if (textContent) {
      const uuid = uuidv4();
      const editUrl = `https://api.satoru.site/api/note/${uuid}`;
      const rawUrl = `https://api.satoru.site/api/note/${uuid}-raw`;

      try {
        await axios.put(editUrl, textContent, {
          headers: { 'content-type': 'text/plain; charset=utf-8' }
        });
        return send(rawUrl);
      } catch (uploadError) {
        console.error("Lỗi khi upload nội dung văn bản lên Satoru.site:", uploadError);
        return send(`❌ Lỗi khi upload nội dung văn bản: ${uploadError.message}`);
      }
    }
  }
};
