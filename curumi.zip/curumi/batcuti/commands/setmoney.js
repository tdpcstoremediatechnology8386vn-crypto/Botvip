module.exports.config = {
 name: "setmoney",
 version: "1.0.2",
 hasPermssion: 2, // Admin mới dùng được
 credits: "Dtyx chỉnh sửa",
 description: "Cộng hoặc chỉnh tiền người dùng (có thể là chính mình)",
 commandCategory: "Hệ thống",
 usages: "[tag|để trống] [set/add] [số tiền]",
 cooldowns: 5
};

module.exports.run = async function ({ event, args, api, Currencies }) {
 const { threadID, messageID, senderID, mentions } = event;

 // Nếu không có đủ 2-3 đối số
 if (args.length < 2 || (args.length < 3 && Object.keys(mentions).length > 0))
 return api.sendMessage(
 `⚠️ Cách dùng:\n• setmoney [tag|để trống] [set/add] [số tiền]\nVí dụ:\n→ setmoney add 1000 (cho chính bạn)\n→ setmoney @User set 5000`,
 threadID, messageID
 );

 // Xác định ID người nhận
 let targetID;
 let action;
 let amount;

 if (Object.keys(mentions).length > 0) {
 targetID = Object.keys(mentions)[0];
 action = args[1].toLowerCase();
 amount = parseInt(args[2]);
 } else {
 targetID = senderID;
 action = args[0].toLowerCase();
 amount = parseInt(args[1]);
 }

 if (!["add", "set"].includes(action))
 return api.sendMessage("❌ Hành động chỉ có thể là 'add' hoặc 'set'.", threadID, messageID);

 if (isNaN(amount))
 return api.sendMessage("❌ Số tiền không hợp lệ.", threadID, messageID);

 try {
 let name = (targetID == senderID) ? "bạn" : mentions[targetID]?.replace("@", "") || "người dùng";
 if (action === "add") {
 await Currencies.increaseMoney(targetID, amount);
 const data = await Currencies.getData(targetID);
 return api.sendMessage(
 `✅ Đã cộng ${amount}$ cho ${name}.\n💰 Hiện có: ${data.money}$`,
 threadID, messageID
 );
 } else {
 await Currencies.setData(targetID, { money: amount });
 return api.sendMessage(
 `✅ Đã đặt số dư của ${name} thành ${amount}$`,
 threadID, messageID
 );
 }
 } catch (e) {
 console.error(e);
 return api.sendMessage("❌ Có lỗi xảy ra khi xử lý.", threadID, messageID);
 }
};