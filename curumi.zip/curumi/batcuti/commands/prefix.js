const fs = require("fs");
const path = require("path");
const moment = require("moment-timezone");
const axios = global.nodemodule['axios'];

module.exports.config = {
  name: "prefix",
  version: "1.0.6",
  hasPermssion: 0,
  credits: "Bat",
  description: "",
  commandCategory: "Tiện ích",
  usages: "prefix",
  cooldowns: 2,
  usePrefix: false
};

// Ghi người dùng vào vdnd.json
async function updateUserData(userID) {
  const userDataPath = path.join(__dirname, "data", "vdnd.json");
  const dir = path.dirname(userDataPath);

  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  let userData = {};
  if (fs.existsSync(userDataPath)) {
    try {
      userData = JSON.parse(fs.readFileSync(userDataPath, "utf8"));
    } catch (err) {
      console.error("❌ Lỗi đọc vdnd.json:", err);
    }
  }

  if (!userData[userID]) {
    userData[userID] = {
      firstJoin: moment().tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || DD/MM/YYYY"),
      count: 1
    };
  } else {
    userData[userID].count += 1;
  }

  try {
    fs.writeFileSync(userDataPath, JSON.stringify(userData, null, 2), "utf8");
  } catch (err) {
    console.error("❌ Lỗi ghi vdnd.json:", err);
  }
}

module.exports.run = async function ({ api, event, args, Threads }) {
  const { threadID, messageID, senderID } = event;
  await updateUserData(senderID);

  const threadData = global.data.threadData.get(threadID) || {};
  const prefix = threadData.PREFIX || global.config.PREFIX;
  const PREFIX = global.config.PREFIX;
  const totalCommands = global.client.commands.size;
  const currentTime = moment().tz("Asia/Ho_Chi_Minh").format("HH:mm:ss || DD/MM/YYYY");

  const userDataPath = path.join(__dirname, "data", "vdnd.json");
  let totalUsers = 0;
  try {
    if (fs.existsSync(userDataPath)) {
      const rawUserData = fs.readFileSync(userDataPath, "utf-8");
      const userData = JSON.parse(rawUserData);
      totalUsers = Object.keys(userData).length;
    }
  } catch (err) {
    console.error("Lỗi đọc file vdnd.json:", err);
  }

  let totalThreads = 0;
  let groupCount = 0;
  try {
    const threads = await Threads.getAll();
    totalThreads = threads.length;
    groupCount = threads.filter(t => t.isGroup).length;
  } catch (e) {
    totalThreads = global.data.allThreadID?.length || 0;
  }

  const dataPath = path.join(__dirname, "data", "vd.json");
  let customGroupCount = 0;
  try {
    if (fs.existsSync(dataPath)) {
      const rawData = fs.readFileSync(dataPath, "utf-8");
      const groupData = JSON.parse(rawData);
      customGroupCount = Object.keys(groupData).length;
    }
  } catch (err) {
    console.error("Lỗi đọc file vd.json:", err);
  }

  const msg = `\n✏️ Prefix nhóm: ${prefix}\n📎 Prefix hệ thống: ${PREFIX}\n` +
              `📝 Tổng lệnh: ${totalCommands}\n👥 Người dùng bot: ${totalUsers}\n` +
              `🏘️ Tổng nhóm: ${customGroupCount}\n` +
              `\n⏰ Thời gian: ${currentTime}`;

  return api.sendMessage({ body: msg, attachment: global.anime?.splice?.(0, 1) }, threadID, (err, info) => {
    if (!err) {
      setTimeout(() => {
        api.unsendMessage(info.messageID);
      }, 20000);
    }
  }, messageID);
};

module.exports.handleEvent = async function ({ api, event }) {
  const { body } = event;
  if (!body) return;

  const args = body.trim().split(/\s+/);
  const first = args[0]?.toLowerCase();

  if ([" "].includes(first)) {
    return this.run({ api, event, args });
  }
};