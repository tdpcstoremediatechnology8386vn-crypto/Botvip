const fs = require('fs');
const path = require('path');
const axios = require('axios');

const statusFile = path.join(__dirname, 'data', 'autodown_status.json');
const platformListReplyMap = new Map();

const platformNames = {
  ig: 'instagram',
  fb: 'facebook',
  pin: 'pinterest',
  scl: 'soundcloud',
  capcut: 'capcut',
  sp: 'spotify',
  x: 'x',
  tiktok: 'tiktok',
  ytb: 'youtube',
  thet: 'threads',
  mp3: 'zingmp3'
};

const platformList = Object.values(platformNames);

module.exports.config = {
  name: 'atd',
  version: '2.2.0',
  hasPermssion: 2,
  credits: 'Ben + Bat',
  description: 'Tải video tự động từ nhiều nền tảng',
  commandCategory: 'atd',
  usages: '[on|off|list] [tên nền tảng]',
  cooldowns: 5,
  prefix: true
};

module.exports.handleEvent = async ({ api, event }) => {
  const url = event.body;
  if (!/^http(s)?:\/\//.test(url)) return;

  const config = getStatus();
  if (!config.global) return;

  const platform = platformList.find(p => url.includes(p));
  if (!platform || config.disabledPlatforms.includes(platform)) return;

  try {
    const res = await axios.get(`https://j2down.vercel.app/download?url=${url}`);
    const data = res.data;
    const medias = data?.medias;

    if (!Array.isArray(medias) || medias.length === 0) return;

    const files = (medias.some(i => i.type === 'image') ? medias : [medias[0]])
      .filter(i => ['image', 'video', 'audio'].includes(i.type))
      .map((item, i) => ({
        path: path.join(__dirname, 'cache', `${Date.now() + i}.${item.type === 'video' ? 'mp4' : item.type === 'audio' ? 'mp3' : 'jpg'}`),
        url: item.url
      }));

    const attachments = [];
    for (const file of files) {
      const stream = await download(file.url, file.path);
      if (!stream.err) attachments.push(stream);
    }

    if (attachments.length) {
      api.sendMessage({
        body: data.title || 'Tệp đã tải về',
        attachment: attachments
      }, event.threadID, null, event.messageID);
    }
  } catch (e) {
    console.error('Download error:', e.message);
  }
};

module.exports.run = async ({ api, event, args }) => {
  const config = getStatus();

  // Nếu không có đối số, hiển thị danh sách nền tảng
  if (!args.length) {
    const enabled = platformList.filter(p => !config.disabledPlatforms.includes(p));
    const disabled = config.disabledPlatforms;

    let msg = 'DANH SÁCH NỀN TẢNG HỖ TRỢ\n';

    enabled.forEach((p, i) => msg += `${i + 1}. ${p} ✅\n`);
    const offset = enabled.length;
    disabled.forEach((p, i) => msg += `${offset + i + 1}. ${p} ❌\n`);

    const indexMap = [...enabled, ...disabled];
    platformListReplyMap.set(event.threadID, { indexMap, messageID: null });

    return api.sendMessage(msg, event.threadID, (err, info) => {
      if (!err) platformListReplyMap.get(event.threadID).messageID = info.messageID;
    });
  }

  const action = args[0]?.toLowerCase();
  const targetInput = args[1]?.toLowerCase();

  // Hỗ trợ cú pháp: all on / all off
  if (action === 'all' && (targetInput === 'on' || targetInput === 'off')) {
    if (targetInput === 'off') {
      config.disabledPlatforms = [...platformList];
    } else {
      config.disabledPlatforms = [];
    }
    saveStatus(config);
    return api.sendMessage(`[AUTODOWN] Đã ${targetInput === 'on' ? 'bật ✅' : 'tắt ❌'} tất cả nền tảng.`, event.threadID, event.messageID);
  }

  // Hỗ trợ bật/tắt toàn bộ hệ thống (global)
  if ((action === 'on' || action === 'off') && !targetInput) {
    config.global = action === 'on';
    saveStatus(config);
    return api.sendMessage(`[AUTODOWN] Đã ${action === 'on' ? 'bật ✅' : 'tắt ❌'} toàn bộ tính năng.`, event.threadID, event.messageID);
  }

  if ((action === 'on' || action === 'off') && targetInput) {
    const platform = platformNames[targetInput];
    if (!platform) {
      return api.sendMessage(`[AUTODOWN] Nền tảng "${targetInput}" không hợp lệ.`, event.threadID, event.messageID);
    }

    if (action === 'off' && !config.disabledPlatforms.includes(platform)) {
      config.disabledPlatforms.push(platform);
    } else if (action === 'on') {
      config.disabledPlatforms = config.disabledPlatforms.filter(p => p !== platform);
    }

    saveStatus(config);
    return api.sendMessage(`[AUTODOWN] Đã ${action === 'on' ? 'bật ✅' : 'tắt ❌'}: ${platform}`, event.threadID, event.messageID);
  }

  return api.sendMessage(`[AUTODOWN] Lệnh không hợp lệ. Dùng "atd" để xem danh sách lệnh.`, event.threadID, event.messageID);
};

module.exports.handleReply = async ({ api, event }) => {
  const { threadID, messageID, body } = event;
  const config = getStatus();

  if (!platformListReplyMap.has(threadID)) return;
  const data = platformListReplyMap.get(threadID);
  if (messageID !== data.messageID) return;

  const index = parseInt(body);
  const platform = data.indexMap[index - 1];
  if (!platform) return api.sendMessage('Sai số thứ tự.', threadID, messageID);

  if (config.disabledPlatforms.includes(platform)) {
    config.disabledPlatforms = config.disabledPlatforms.filter(p => p !== platform);
    api.sendMessage(`[AUTODOWN] Đã BẬT lại ✅: ${platform}`, threadID, messageID);
  } else {
    config.disabledPlatforms.push(platform);
    api.sendMessage(`[AUTODOWN] Đã TẮT ❌: ${platform}`, threadID, messageID);
  }

  saveStatus(config);
  platformListReplyMap.delete(threadID);
};

async function download(url, filePath) {
  try {
    // Kiểm tra và tạo thư mục cache nếu không tồn tại
    const cacheDir = path.join(__dirname, 'cache');
    if (!fs.existsSync(cacheDir)) {
      fs.mkdirSync(cacheDir, { recursive: true });
    }

    // Tải dữ liệu từ URL và lưu vào file
    const res = await axios.get(url, { responseType: 'arraybuffer' });
    fs.writeFileSync(filePath, res.data);

    // Xóa tệp sau 60 giây
    setTimeout(() => fs.unlink(filePath, () => {}), 60 * 1000);

    // Trả về stream tệp đã lưu
    return fs.createReadStream(filePath);
  } catch (e) {
    console.error('Tải lỗi:', e.message);
    return { err: true };
  }
}

function getStatus() {
  try {
    if (!fs.existsSync(statusFile)) {
      fs.writeFileSync(statusFile, JSON.stringify({ global: true, disabledPlatforms: [] }));
    }
    return JSON.parse(fs.readFileSync(statusFile, 'utf-8'));
  } catch {
    return { global: true, disabledPlatforms: [] };
  }
}

function saveStatus(config) {
  fs.writeFileSync(statusFile, JSON.stringify(config, null, 2));
}