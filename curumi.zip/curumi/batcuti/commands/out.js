module.exports.config = {
  name: "out",
  version: "1.0.0",
  hasPermssion: 2, // Chỉ admin bot hoặc người có quyền mới được dùng
  credits: "Nhi",
  description: "Bot tự rời khỏi nhóm",
  commandCategory: "Admin",
  usages: "[out]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  const threadID = event.threadID;
  const senderID = event.senderID;

  // Kiểm tra xem bot có đang ở trong nhóm không
  try {
    await api.sendMessage("Tạm biệt mọi người 👋", threadID);
    await api.removeUserFromGroup(api.getCurrentUserID(), threadID);
  } catch (err) {
    return api.sendMessage("❌ Không thể rời khỏi nhóm. Có thể bot không đủ quyền.", threadID);
  }
};