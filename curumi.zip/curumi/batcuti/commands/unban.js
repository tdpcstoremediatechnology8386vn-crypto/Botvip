module.exports.config = {
  name: "unban",
  version: "1.0.0",
  hasPermssion: 3,
  credits: "ManhG",
  description: "Gỡ ban nhóm và người dùng",
  commandCategory: "Admin",
  usages: "unban [admin|ndh|box|allbox|user|alluser|qtv|allqtv|member]",
  cooldowns: 2
};

module.exports.run = async ({ event, api, Users, Threads, args }) => {
  const { threadID, messageID, senderID, mentions, participantIDs } = event;
  const { commands } = global.client;
  const command = commands.get("unban");
  if (command.config.credits !== "ManhG")
    return api.sendMessage(`Sai credit!`, threadID, messageID);

  const unbanUser = async (id) => {
    const data = (await Users.getData(id)).data || {};
    data.banned = 0;
    data.reason = null;
    data.dateAdded = null;
    await Users.setData(id, { data });
    global.data.userBanned.delete(id);
  };

  const unbanThread = async (id) => {
    const data = (await Threads.getData(id)).data || {};
    data.banned = 0;
    data.reason = null;
    data.dateAdded = null;
    await Threads.setData(id, { data });
    global.data.threadBanned.delete(id);
  };

  switch ((args[0] || "").toLowerCase()) {
    case "admin":
    case "ad":
      for (const id of global.config.ADMINBOT) await unbanUser(id);
      return api.sendMessage("Đã gỡ ban cho toàn bộ Admin Bot", threadID, messageID);

    case "ndh":
      for (const id of global.config.NDH) await unbanUser(id);
      return api.sendMessage("Đã gỡ ban cho toàn bộ Người hỗ trợ", threadID, messageID);

    case "allbox":
    case "allthread":
      for (const id of global.data.threadBanned.keys()) await unbanThread(id);
      return api.sendMessage("Đã gỡ ban cho toàn bộ nhóm", threadID, messageID);

    case "box":
    case "thread":
      await unbanThread(threadID);
      return api.sendMessage("Đã gỡ ban cho nhóm hiện tại", threadID, messageID);

    case "alluser":
    case "allmember":
      for (const id of global.data.userBanned.keys()) await unbanUser(id);
      return api.sendMessage("Đã gỡ ban cho toàn bộ người dùng", threadID, messageID);

    case "qtvall":
    case "allqtv":
      const allThreads = await Threads.getAll();
      for (const thread of allThreads) {
        const adminIDs = thread.threadInfo?.adminIDs || [];
        for (const { id } of adminIDs) await unbanUser(id);
      }
      return api.sendMessage("Đã gỡ ban cho toàn bộ Quản trị viên", threadID, messageID);

    case "qtv":
      const threadInfo = (await Threads.getData(threadID)).threadInfo || {};
      for (const { id } of threadInfo.adminIDs || []) await unbanUser(id);
      return api.sendMessage("Đã gỡ ban cho toàn bộ Quản trị viên nhóm này", threadID, messageID);

    case "member":
    case "mb":
    case "user":
      if (args[1]?.includes("@")) {
        const id = Object.keys(mentions)[0];
        await unbanUser(id);
        const name = mentions[id];
        return api.sendMessage(`Đã gỡ ban người dùng ${name}`, threadID, messageID);
      } else {
        for (const id of participantIDs) await unbanUser(id);
        return api.sendMessage("Đã gỡ ban toàn bộ thành viên nhóm", threadID, messageID);
      }

    default:
      return api.sendMessage(
        `Unban Config:\n` +
        `• unban admin      → Gỡ ban toàn bộ Admin Bot\n` +
        `• unban ndh        → Gỡ ban toàn bộ Người hỗ trợ\n` +
        `• unban allbox     → Gỡ ban toàn bộ nhóm\n` +
        `• unban box        → Gỡ ban nhóm hiện tại\n` +
        `• unban alluser    → Gỡ ban toàn bộ người dùng\n` +
        `• unban allqtv     → Gỡ ban toàn bộ Quản trị viên\n` +
        `• unban qtv        → Gỡ ban QTV nhóm hiện tại\n` +
        `• unban member     → Gỡ ban toàn bộ thành viên nhóm\n` +
        `• unban member tag → Gỡ ban người được tag`,
        threadID, messageID
      );
  }
};