const fs = require("fs-extra");
const axios = require("axios");
const moment = require("moment-timezone");

module.exports.config = {
  name: "joinNoti",
  eventType: ["log:subscribe"],
  version: "1.0.2",
  credits: "HĐGN (refactored by GPT)",
  description: "Thông báo khi bot hoặc thành viên vào nhóm, kèm gif/ảnh/video ngẫu nhiên",
  dependencies: { "fs-extra": "", "path": "", "pidusage": "" }
};

module.exports.run = async function ({ api, event, Users, Threads }) {
  const threadID = event.threadID;
  const timeNow = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");

  const threadSetting = (await Threads.getData(String(threadID))).data || {};
  const prefix = threadSetting.PREFIX || global.config.PREFIX;
  const threadData = global.data.threadData.get(threadID) || {};

  if (threadData.join === false) return;

  const isBotJoin = event.logMessageData.addedParticipants.some(i => i.userFbId == api.getCurrentUserID());

  if (isBotJoin) {
    try {
      const info = await api.getThreadInfo(threadID);
      const admins = await Promise.all(info.adminIDs.map(async (adm) => {
        const u = await Users.getInfo(adm.id);
        return `• ${u.name}`;
      }));

      api.changeNickname(`${global.config.BOTNAME}`, threadID, api.getCurrentUserID());

      const msg = `🔄 Đang kết nối vui lòng chờ...`;
      api.sendMessage(msg, threadID, async (err, infoMsg) => {
        if (!err) {
          await new Promise(res => setTimeout(res, 9000));
          await api.unsendMessage(infoMsg.messageID);
        }
      });

      // ✅ Thông báo đã load bot + ảnh từ global.anime
      setTimeout(async () => {
        const summary =
          `✅ Bot đã load thành công!\n` +
          `📝 Hãy sử dụng ${prefix}menu all để xem toàn bộ lệnh của bot\n` +
          `⛔ Vui lòng không spam bot để tránh bị khóa!`;

        const sendMsg = await api.sendMessage({
          body: summary,
          attachment: global.vdgai.splice(0, 1)
        }, threadID);

        setTimeout(() => api.unsendMessage(sendMsg.messageID), 60 * 1000);
      }, 12000);
    } catch (err) {
      console.error("Lỗi khi xử lý bot join:", err);
    }
    return;
  }

  try {
    const pathData = `${global.client.mainPath}/batcuti/commands/data/dataEvent.json`;
    const dataE = JSON.parse(fs.readFileSync(pathData));
    const findT = dataE.join.find(i => i.threadID === threadID);
    if (findT && !findT.status) return;

    const info = await api.getThreadInfo(threadID);
    const time = moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss");

    let mentions = [], names = [], ids = [], positions = [], i = 0;
    for (const p of event.logMessageData.addedParticipants) {
      names.push(p.fullName);
      ids.push(p.userFbId.toString());
      mentions.push({ tag: p.fullName, id: event.senderID });
      positions.push(info.participantIDs.length - i++);
    }
    positions.sort((a, b) => a - b);

    const nameAuthor = await Users.getNameUser(event.author);
    const msgTemplate = threadData.customJoin || 
      `👤 Xin chào bạn {name}\n` +
      `🤟 Chào mừng đã đến với chiêm\n` +
      `👥 {type} là thành viên thứ {soThanhVien} của nhóm\n` +
      `📌Bạn hãy tương tác đầy đủ nếu không muốn cút!\n` +
      `🗓️ Thời gian hiện tại: {time}`;

    const message = msgTemplate
      .replace(/\{name}/g, names.join(', '))
      .replace(/\{iduser}/g, ids.join(', '))
      .replace(/\{type}/g, (names.length > 1) ? "Các bạn" : "Bạn")
      .replace(/\{soThanhVien}/g, positions.join(', '))
      .replace(/\{threadName}/g, info.threadName)
      .replace(/\{author}/g, nameAuthor)
      .replace(/\{uidAuthor}/g, event.author)
      .replace(/\{time}/g, time);

    const sendData = {
      body: message,
      attachment: global.vdcos.splice(0, 1)
    };

    const sent = await api.sendMessage(sendData, threadID);
    setTimeout(() => api.unsendMessage(sent.messageID), 20000);
  } catch (err) {
    console.error("Lỗi khi xử lý user join:", err);
  }
};