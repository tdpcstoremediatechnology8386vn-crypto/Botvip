const axios = require("axios");
const moment = require("moment-timezone");
const fs = require('fs');

module.exports.config = {
  name: "leaveNoti",
  eventType: ["log:unsubscribe"],
  version: "1.0.0",
  credits: "Không biết (mod by GPT)",
  description: "Thông báo bot hoặc người rời khỏi nhóm có random gif/ảnh/video",
  dependencies: {
    "fs-extra": "",
    "path": ""
  }
};

const checkttPath = __dirname + '/../commands/checktt/';

module.exports.run = async function ({ api, event, Users, Threads }) {
  try {
    const { threadID } = event;
    const { mainPath } = global.client;
    const pathLeave = mainPath + '/batcuti/commands/data/dataEvent.json';
    const dataLeave = JSON.parse(fs.readFileSync(pathLeave));
    const findLeave = dataLeave.leave.find(i => i.threadID === threadID);
    if (findLeave && !findLeave.status) return;

    if (event.logMessageData.leftParticipantFbId == api.getCurrentUserID()) return;

    const iduser = event.logMessageData.leftParticipantFbId;
    const name = global.data.userName.get(iduser) || await Users.getNameUser(iduser);
    const threadInfo = await Threads.getData(threadID);
    const threadName = threadInfo.threadInfo.threadName || "nhóm";

    const rawTime = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss (DD/MM/YYYY)");
    const time = `${rawTime} sáng`;

    // Xoá dữ liệu checktt nếu có
    if (fs.existsSync(checkttPath + threadID + '.json')) {
      const threadData = JSON.parse(fs.readFileSync(checkttPath + threadID + '.json'));
      const removeFrom = key => {
        const index = threadData[key].findIndex(e => e.id == iduser);
        if (index != -1) threadData[key].splice(index, 1);
      };
      removeFrom("total");
      removeFrom("week");
      removeFrom("day");
      fs.writeFileSync(checkttPath + threadID + '.json', JSON.stringify(threadData, null, 4));
    }

    // Soạn nội dung tin nhắn
    const msg =
      `👤 Thành viên: ${name}\n` +
      `👥️️ Đã rời khỏi nhóm: ${threadName}\n` +
      `⏰ vào lúc: ${time}\n` +
      `📛 Url facebook: https://facebook.com/${iduser}`;

    return api.sendMessage(
      { body: msg, attachment: global.vdtrai.splice(0, 1) },
      threadID,
      async (err, info) => {
        await new Promise(resolve => setTimeout(resolve, 20 * 1000));
        return api.unsendMessage(info.messageID);
      }
    );

  } catch (e) {
    console.error("Lỗi trong leaveNoti:", e);
  }
};